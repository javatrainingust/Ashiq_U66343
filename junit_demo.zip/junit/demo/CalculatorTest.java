package com.ust.junit.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest {

	@Test
	void testAdd() {
		
		int expected=7;
		Calculator calculator=new Calculator();
		
		int actual= calculator.add(4, 3);
		assertEquals(expected, actual);
	}
	
	@Test
	void testSubtract() {
		
		int expected=1;
		Calculator calculator=new Calculator();
		
		int actual= calculator.subtract(4, 3);
		assertEquals(expected, actual);
	}

}
