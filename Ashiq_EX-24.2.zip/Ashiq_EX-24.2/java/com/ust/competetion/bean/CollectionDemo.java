/**
 * Name:CollectionDemo
 * Description: CollectionDemo class is for demo.
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * This class contains main method which calls the perform method of OneManBand
 * */
public class CollectionDemo {
	/**
	 * Main method which calls the perform method of OneManBand
	 * */
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		OneManBand oneManBand= context.getBean("onemanband", OneManBand.class);
		oneManBand.perform();
	}

}
