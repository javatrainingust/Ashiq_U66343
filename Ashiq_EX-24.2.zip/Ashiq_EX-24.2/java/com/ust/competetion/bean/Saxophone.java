/**
 * Name:Saxophone
 * Description: Saxophone contains a play method. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;


/**
 * This class implements Instruments. 
 * */
public class Saxophone implements Instrument{
	/**
	 * This play method will print some text. 
	 * */
	public void play() {
		
		System.out.println("Play from saxophone");
		
	}

}
