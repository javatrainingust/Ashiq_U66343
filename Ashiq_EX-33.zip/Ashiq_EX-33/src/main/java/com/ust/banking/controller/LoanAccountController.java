/**
 * Name: LoanAccountController
 * Descriptions: LoanAccountController class is controller class. 
 * Date: 15/10/2020
 */

package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.LoanAccount;

import com.ust.banking.service.LoanAccountService;

/**
 * This controller class contains a method to return all the loan accounts. 
 * */
@Controller
public class LoanAccountController {
	

	@Autowired
	LoanAccountService loanAccountService;
	/**
	 * This method will returns all the loan accounts to a jsp page. 
	 * */
	@RequestMapping("/getAllLoanAccount")
	public String getAllLoanAccount(Model model) {
		
		List<LoanAccount> listOfLoanAccounts= loanAccountService.getAllLoanAccount();
		model.addAttribute("loanAccount", listOfLoanAccounts);
		return "showAllLoanAccounts";
	}
	/**
	 * This method will return one loan account
	 * */
	@RequestMapping("/getOneLoanAccount")
	public String getOneLoanAccountByNumber(@RequestParam("number") String number, Model model) {
		
		LoanAccount loanAccount= loanAccountService.getLoanAccountByNumber(Integer.parseInt(number));
		model.addAttribute("key", loanAccount);
		return "viewOneLoanAccount";
	}
	/**
	 * This method will delete one Loan account
	 * */
	@RequestMapping("/deleteOneLoanAccount")
	public String deleteOneLoanAccountByNumber(@RequestParam("number") String number, Model model) {
		
		loanAccountService.deleteOneAccount(Integer.parseInt(number));
		
		return "redirect:/getAllLoanAccount";
	}
}
