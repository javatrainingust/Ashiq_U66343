/**
 * Name: FunctionDemo
 * Description: FunctionDemo class demonstrating the functionality of Function functional interface. 
 * Date: 08/10/2020
 */

package com.ust.functionalinterface.demo;

import java.util.function.Function;

/**
 * This class demonstrating the functionality of Function functional interface, it convert a string to upper case. 
 * */
public class FunctionDemo {

	/**
	 * The main method a functional interface which converts a string to upper case and printing it. 
	 * */
	public static void main(String[] args) {
		
		Function<String, String> capital= (n)->n.toUpperCase();
		System.out.println(capital.apply("convert to upper case"));

	}

}
