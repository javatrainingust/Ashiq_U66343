/**
 * Name:PredicateDemo
 * Description: PredicateDemo class demonstrating the functionality of predicate functional interface. 
 * Date:08/10/2020
 */

package com.ust.functionalinterface.demo;

import java.util.function.Predicate;

/**
 * This class contains a main method which is for checking a number greater than 50 or not. 
 * */
public class PredicateDemo {
	
	/**
	 * Main method contains the predicate functional interface which checks a number greater than 50 or not, and it prints the status. 
	 * */
	public static void main(String[] args) {

		Predicate<Integer> isGreater= (n)->n>50;
		
		System.out.println(isGreater.test(20));

	}

}
