/**
 * Name: ConsumerDemo
 * Description: ConsumerDemo class demonstrating the functionality of Consumer functional interface. 
 * Date: 08/10/2020
 */

package com.ust.functionalinterface.demo;

import java.util.function.Consumer;

/**
 * This class contains a method which will convert a string to upper case.
 * */
public class ConsumerDemo {
	
	/**
	 * Main method contains a consumer functional interface which converting a string to upper case. 
	 * */
	public static void main(String[] args) {
		
		Consumer<String> string= (n)-> System.out.println(n.toUpperCase());
		
		string.accept("convert to upper case");
	}

}
