/**
 * Name:SupplierDemo
 * Description: SupplierDemo class demonstrating the functionality of Supplier functional interface. 
 * Date:08/10/2020
 */

package com.ust.functionalinterface.demo;

import java.util.function.Supplier;

/**
 * This class contains a method which generating random number using Supplier functional interface.
 * */
public class SupplierDemo {
	
	/**Main method will generate a random number and printing it*/
	public static void main(String[] args) {
		
		Supplier<Double> number=()->Math.random();
		System.out.println(number.get());
	}
}
