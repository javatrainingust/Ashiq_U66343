/**
 * Name:FDSortedBalance 
 * Descriptions: FDSortedBalance class is for sorting in terms of balance.  
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Comparator;

import com.ust.banking.Entity.FDAccount;
/**This class implements the compare method of Comparator interface*/
public class FDSortedBalance implements Comparator<FDAccount>{

	/**Implementation for compare method*/
	@Override
	public int compare(FDAccount balanceA, FDAccount balanceB) {
		// TODO Auto-generated method stub
		return (int) (balanceA.getFDBalance()-balanceB.getFDBalance());
	}

}
