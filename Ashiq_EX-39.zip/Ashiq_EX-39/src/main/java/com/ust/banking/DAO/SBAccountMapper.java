/**
 * Name: SBAccountMapper
 * Description: This is class implements the RowMaper class
 * Date: 23/10/2020
 */

package com.ust.banking.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.banking.Entity.SBAccount;

/**
 * This class implements the RowMaper class. 
 * */
public class SBAccountMapper implements RowMapper<SBAccount>{

	/**
	 * This is implementation method for mapRow
	 * */
	@Override
	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		SBAccount sbAccount= new SBAccount();
		sbAccount.setAccountNumber(rs.getInt("accountNumber"));
		sbAccount.setAccountHolderName(rs.getString("accountHolderName"));
		sbAccount.setMinimumBalance(rs.getFloat("minimumBalance"));
		sbAccount.setSBBalance(rs.getFloat("SBBalance"));
		return sbAccount;
	}

}
