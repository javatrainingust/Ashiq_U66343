/**
 *Name: LoanAccount
 *Description: LoanAccount class is for customers having loan account, and which inherits from Account class. 
 *Date: 30/09/2020
 */

package com.ust.banking.Entity;
/**
 * This LoanAccount class contains variables emi, loanoutstanding and tenure. Also it impelements comparable interface. 
 */
public class LoanAccount extends Account implements Comparable<LoanAccount>{
	
	private float emi;
	private float loanOutStanding;
	/**Getter for emi*/
	public float getEmi() {
		return emi;
	}
/**Setter for emi*/
	public void setEmi(float emi) {
		this.emi = emi;
	}
	/**Getter for tenure*/
	public int getTenure() {
		return tenure;
	}
	/**Setter for tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	/**Setter for loan out standing amount*/
	public void setLoanOutStanding(float loanOutStanding) {
		this.loanOutStanding = loanOutStanding;
	}

	private int tenure;
	
	/**Getter for loan out standing amount*/
	public float getLoanOutStanding() {
		return loanOutStanding;
	}
	/**No argument constructor for CurrentAccount class*/
	public LoanAccount() {}
	
	/**Argument constructor for CurrentAccount class*/
	public LoanAccount(int accountNumber, String accountHolderName, float emi, float loanOutStanding, int tenure) {
		super(accountNumber, accountHolderName);
		this.emi = emi;
		this.loanOutStanding = loanOutStanding;
		this.tenure = tenure;
	}
	/**This method is for EMI calculation*/
	public float calcEmi(int tenure, float loanAmount) {
		this.emi=(float) ((loanAmount/tenure)*1.5);
		return emi;
	}
	@Override
	public int compareTo(LoanAccount account) {
		// TODO Auto-generated method stub
		return getAccountHolderName().compareTo(account.getAccountHolderName());
	}
	
	

}
