/**
 * Name: SBAccountController
 * Descriptions: SBAccountController class is controller class. 
 * Date: 22/10/2020
 */

package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.SBAccountService;

/**
 * This controller class contains a method , it returns all SB accounts.
 */
@RestController
public class SBAccountController {
	@Autowired
	SBAccountService sbAccountService;
	
	/**
	 * This method will returns all SB accounts.
	 */
	@RequestMapping(value = "/sbaccounts", method = RequestMethod.GET)
	public List<SBAccount> getAllSBAccount() {

		List<SBAccount> listOfSbAccounts = sbAccountService.getAllSBAccount();

		return listOfSbAccounts;
	}

	/**
	 * this method is to get one account by number
	 * */
	@RequestMapping(value = "/sbaccounts/{number}", method = RequestMethod.GET)
	public SBAccount getOneSBAccountByNumber(@PathVariable int number) {

		SBAccount sbAccount = sbAccountService.getSBAccountByNumber(number);

		return sbAccount;
	}

	/**
	 * This method will update the account details.
	 */
	@RequestMapping(value = "/sbaccounts/{number}", method = RequestMethod.PUT)
	public SBAccount updateSBAccount(@PathVariable int number, @RequestBody SBAccount sbAccount) {

		if (sbAccountService.getSBAccountByNumber(number) != null) {
			sbAccountService.updateAccount(sbAccount);

			return sbAccount;
		}
		return null;
	}

	@RequestMapping(value = "/sbaccounts/{number}", method = RequestMethod.DELETE)
	public boolean deleteOneSBAccountByNumber(@PathVariable int number) {

		if (sbAccountService.getSBAccountByNumber(number) != null) {
			sbAccountService.deleteOneAccount(number);
			return true;
		}

		return false;
	}

	/**
	 * This method will add SB account
	 */
	@RequestMapping(value = "/sbaccounts", method = RequestMethod.POST)
	public String addSBAccount(@RequestBody SBAccount sbAccount) {

		if (sbAccountService.getSBAccountByNumber(sbAccount.getAccountNumber()) == null) {
			sbAccountService.addSBAccount(sbAccount);
			return "Account added";

		}
		return "Account already exist";

	}

	/*
	*//**
		 * This method will returns all SB accounts to jsp page.
		 */
	/*
	 * @RequestMapping("/getAllSBAccountSortByBalance") public String
	 * getAllSBAccountSortByBalance(Model model) {
	 * 
	 * List<SBAccount> listOfSbAccounts=
	 * sbAccountService.getAllSBAccountSortedByBalance();
	 * model.addAttribute("sbAccount", listOfSbAccounts); return
	 * "redirect:/getAllSBAccount"; }
	 * 
	 *//**
		 * This method will update the account details.
		 */
	/*
	 * @RequestMapping("/updateSBAccount") public String
	 * updateSBAccount(@ModelAttribute("sbAccount") SBAccount sbAccount) {
	 * 
	 * sbAccountService.updateAccount(sbAccount); return
	 * "redirect:/getAllSBAccount"; }
	 * 
	 *//**
		 * This method is to show the SB account form
		 */
	/*
	 * @RequestMapping("/showSBAccountForm") public String showSBAccountForm(Model
	 * model) {
	 * 
	 * SBAccount sbAccount= new SBAccount(); model.addAttribute("key", sbAccount);
	 * return "addSBAccountForm";
	 * 
	 * }
	 *//**
		 * This method will add SB account
		 */
	/*
	 * @RequestMapping("/addSBAccount") public String
	 * addSBAccount(@ModelAttribute("sbAccount") SBAccount sbAccount){
	 * 
	 * sbAccountService.addSBAccount(sbAccount); return "redirect:/getAllSBAccount";
	 * 
	 * }
	 * 
	 * 
	 * 
	 *//**
		 * This method will returns all SB accounts to jsp page.
		 */
	/*
	 * @RequestMapping("/getAllSBAccount") public String getAllSBAccount(Model
	 * model) {
	 * 
	 * List<SBAccount> listOfSbAccounts= sbAccountService.getAllSBAccount();
	 * model.addAttribute("sbAccount", listOfSbAccounts); return
	 * "showAllSBAccounts"; }
	 *//**
		 * This method will return one SB account
		 */
	/*
	 * @RequestMapping("/getOneSBAccount") public String
	 * getOneSBAccountByNumber(@RequestParam("number") String number, Model model) {
	 * 
	 * SBAccount sbAccount=
	 * sbAccountService.getSBAccountByNumber(Integer.parseInt(number));
	 * model.addAttribute("key", sbAccount); return "viewOneSBAccount"; }
	 *//**
		 * This method will delete one SB account
		 *//*
			 * @RequestMapping("/deleteOneSBAccount") public String
			 * deleteOneSBAccountByNumber(@RequestParam("number") String number, Model
			 * model) {
			 * 
			 * sbAccountService.deleteOneAccount(Integer.parseInt(number));
			 * 
			 * return "redirect:/getAllSBAccount"; }
			 */
}
