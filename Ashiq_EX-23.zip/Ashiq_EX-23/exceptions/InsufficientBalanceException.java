/**
 * Name: InsufficientBalanceException
 * Description: InsufficientBalanceException class is user defined exception class.
 * Date: 06/10/2020
 */

package com.ust.banking.exceptions;

/**
 * This class is for is user defined exception.
 * */
public class InsufficientBalanceException extends Exception{

	float amount;
	
	public InsufficientBalanceException(float amount) {
		
		this.amount=amount;
	}
	/**
	 * overrided toString method. 
	 * 
	 * */
	@Override
	public String toString() {
		return "You don't have enough amount to take "+this.amount +" rupees";
	}
	
	
}
