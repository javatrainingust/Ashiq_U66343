/**
 * Name: 
 * Descriptions:CurrentAccountSortedOverdraftLimit class is for sorting in terms of overdraft limit 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Comparator;

import com.ust.banking.Entity.CurrentAccount;

/**This class implements the compare method of Comparator interface*/

public class CurrentAccountSortedOverdraftLimit implements Comparator<CurrentAccount>{
	
	/**Implementation for compare method*/
	@Override
	public int compare(CurrentAccount account1, CurrentAccount account2) {
		// TODO Auto-generated method stub
		return (int) (account1.getOverDraftLimit()-account2.getOverDraftLimit());
	}

}
