/**
 * Name: LoanAccountServiceTest
 * Descriptions: LoanAccountServiceTest class is for testing LoanAccountService class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.LoanAccountService;

/**
 * This class contains testing methods get all loan account sorted by name and
 * get all loan account sorted by loan outstanding.
 * 
 */

class LoanAccountServiceTest {

	List<LoanAccount> loanAccountList;
	LoanAccountService loanAccountService;
	
	/** Constructor for LoanAccountServiceTest */

	public LoanAccountServiceTest() {
		loanAccountService= new LoanAccountService();
		/*
		 * loanAccountList = new ArrayList<>(); LoanAccount loanAccount1 = new
		 * LoanAccount(11141, "Loan Account Holder A", 500, 10000, 3); LoanAccount
		 * loanAccount2 = new LoanAccount(11142, "Loan Account Holder C", 5000, 210000,
		 * 5); LoanAccount loanAccount3 = new LoanAccount(11143,
		 * "Loan Account Holder B", 100, 20000, 30); LoanAccount loanAccount4 = new
		 * LoanAccount(11144, "Loan Account Holder D", 500, 10000, 3);
		 * loanAccountList.add(loanAccount1); loanAccountList.add(loanAccount2);
		 * loanAccountList.add(loanAccount3); loanAccountList.add(loanAccount4);
		 */
		
		loanAccountService.addLoanAccount( new LoanAccount(11141, "Loan Account Holder A", 500, 10000, 3));
		loanAccountService.addLoanAccount(new LoanAccount(11142, "Loan Account Holder C", 5000, 210000, 5));
		
	}

	/** Method is test for add account success*/
	@Test
	void testAddLoanAccountSuccess() {

		assertTrue(loanAccountService.addLoanAccount(new LoanAccount(11143, "Loan Account Holder B", 500, 10000, 3)));
	}

	/** Method is test for add account failure */
	@Test
	void testAddLoanAccountFailure() {

		assertFalse(loanAccountService.addLoanAccount( new LoanAccount(11141, "Loan Account Holder A", 500, 10000, 3)));
	}

	
	/** Method is test for update account success*/
	@Test
	void testUpdateLoanAccountSuccess() {
		
		assertTrue(loanAccountService.updateAccount( new LoanAccount(11142, "Loan Account Holder Updated name", 500, 10000, 3)));
	}
	
	/** Method is test for update account success failure*/
	@Test
	void testUpdateLoanAccountFailure() {
		assertFalse(loanAccountService.updateAccount(new LoanAccount(11148, "Loan Account Holder C", 5000, 210000, 5)));
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/** Method is test for get all loan account sorted by name */
	/*
	 * @Test void testGetAllLoanAccountSortedByName() {
	 * 
	 * List<String> expectedListOfName = new ArrayList<>(); for (LoanAccount
	 * loanAccount : loanAccountList) {
	 * expectedListOfName.add(loanAccount.getAccountHolderName()); }
	 * Collections.sort(expectedListOfName);
	 * 
	 * LoanAccountService loanAccountService = new LoanAccountService();
	 * List<LoanAccount> actual =
	 * loanAccountService.getAllLoanAccountSortedByName(); List<String>
	 * actualListOfName = new ArrayList<>(); for (LoanAccount loanAccount : actual)
	 * { actualListOfName.add(loanAccount.getAccountHolderName()); }
	 * assertEquals(expectedListOfName, actualListOfName); }
	 * 
	 *//** Method is test for get all FD account sorted by loan outstanding *//*
																				 * @Test void
																				 * testGetAllLoanAccountSortedByLoanOutStanding
																				 * () {
																				 * 
																				 * List<Float>
																				 * expectedListOfLoanOutstandingAmount =
																				 * new ArrayList<>(); for (LoanAccount
																				 * loanAccount : loanAccountList) {
																				 * expectedListOfLoanOutstandingAmount.
																				 * add(loanAccount.getLoanOutStanding())
																				 * ; } Collections.sort(
																				 * expectedListOfLoanOutstandingAmount);
																				 * 
																				 * LoanAccountService loanAccountService
																				 * = new LoanAccountService();
																				 * List<LoanAccount> actual =
																				 * loanAccountService.
																				 * getAllLoanAccountSortedByLoanOutStanding
																				 * (); List<Float>
																				 * actualListOfLoanOutstandingAmount =
																				 * new ArrayList<>();
																				 * 
																				 * for (LoanAccount loanAccount :
																				 * actual) {
																				 * actualListOfLoanOutstandingAmount.add
																				 * (loanAccount.getLoanOutStanding()); }
																				 * assertEquals(
																				 * expectedListOfLoanOutstandingAmount,
																				 * actualListOfLoanOutstandingAmount); }
																				 */
}
