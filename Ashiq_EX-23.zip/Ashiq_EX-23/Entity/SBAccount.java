/**
 *Name: SBAccount
 *Description: SBAccount class is for customers having SB account, and which inherits from Account class. 
 *Date: 30/09/2020
 */

package com.ust.banking.Entity;

import com.ust.banking.exceptions.InsufficientBalanceException;

/**
 * This SBAccount class contains variables minimum balance, SBBalance. Also it impelements comparable interface. 
 */
public class SBAccount extends Account implements Comparable<SBAccount>{
	
	private float minimumBalance;
	private float SBBalance=1000;
	
	/** getter method for balance*/
	public float getSBBalance() {
		return SBBalance;
	}
	/** getter method for minimum balance*/
	public float getMinimumBalance() {
		return minimumBalance;
	}
	/**Argument constructor for SB Account*/
	public SBAccount(int accountNumber, String accountHolderName, float minimumBalance, float SBBalance) {
		super(accountNumber, accountHolderName);
		this.minimumBalance = minimumBalance;
		this.SBBalance=SBBalance;
	}
	/**Setter method for minimum balalnce*/
	public void setMinimumBalance(float minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	/**No argument constructor for account class*/
	public SBAccount() {
		
	}
	/**Implementation for compareTo method*/
	@Override
	public int compareTo(SBAccount account) {
		// TODO Auto-generated method stub
		return getAccountHolderName().compareTo(account.getAccountHolderName());
	}
	/**withdraw money method to withdraw money from SB account*/
	public float withdrawMoney(float amountToWithdraw) throws InsufficientBalanceException {
		
		if(amountToWithdraw>SBBalance) {
			throw new InsufficientBalanceException(amountToWithdraw);
		}
		else {
			this.SBBalance=SBBalance-amountToWithdraw;
			return SBBalance;
		}
	}
}
