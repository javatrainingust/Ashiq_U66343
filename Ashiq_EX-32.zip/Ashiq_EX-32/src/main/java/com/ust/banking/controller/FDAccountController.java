/**
 * Name: FDAccountController
 * Descriptions: FDAccountController class is controller class. 
 * Date: 15/10/2020
 */

package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.banking.Entity.FDAccount;
import com.ust.banking.service.FDAccountService;
/**
 * This class contains a method to get all the FD accounts.  
 * */
@Controller
public class FDAccountController {
	
	
	@Autowired
	FDAccountService fdAccountService;
	/**
	 * This method will return all the fd accounts to showAllFDAccounts jsp page. 
	 * */
	@RequestMapping("/getAllFDAccount")
	public String getAllFDAccount(Model model) {
		
		List<FDAccount> listOfFdAccounts= fdAccountService.getAllFdAccount();
		model.addAttribute("fdAccount", listOfFdAccounts);
		return "showAllFDAccounts";
	}
	/**
	 * This method will return one fd account
	 * */
	@RequestMapping("/getOneFDAccount")
	public String getOneFDAccountByNumber(@RequestParam("number") String number, Model model) {
		
		FDAccount fdAccount= fdAccountService.getFDAAccountByNumber(Integer.parseInt(number));
		model.addAttribute("key", fdAccount);
		return "viewOneFDAccount";
	}
}
