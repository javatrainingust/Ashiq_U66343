/**
 * Name:PerformanceDemo
 * Description: PerformanceDemo class is for demo.
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * This class is demo, contains main method
 * */
public class PerformanceDemo {
	
	/**
	 * Main method- here we are calling perform method in singer class. 
	 * */
	public static void main(String[] args) {
		
		
		  ClassPathXmlApplicationContext context= new ClassPathXmlApplicationContext("applicationContext.xml");
		 // Singer singer=context.getBean("singer", Singer.class); 
		  //singer.perform();
		 
		
		Instrumentalist instrumentalist= context.getBean("instrumentalist", Instrumentalist.class);
		instrumentalist.perform();
	}

}
