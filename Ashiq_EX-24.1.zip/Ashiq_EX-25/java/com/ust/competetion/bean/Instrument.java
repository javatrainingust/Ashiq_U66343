/**
 * Name:Instrument
 * Description: Instrument interface contains a method play. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

/**
 * This class contains a method play.
 * */
public interface Instrument {
	/**
	 * This play method will implement in the implementation class.
	 * */
	public void play();
	
}
