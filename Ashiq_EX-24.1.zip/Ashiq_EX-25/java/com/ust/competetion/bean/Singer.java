/**
 * Name:Singer
 * Description: Singer class contains a property song and implementation of performer. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

/**
 * This class implements performer interface. 
 * */
public class Singer implements Performer{
	

	public String song;
	
	/**
	 * Argumented constructor. 
	 * */
	public Singer(String song) {
		this.song=song;
	}
	/**
	 * Default constructor. 
	 * */
	public Singer() {}
	
	/**
	 * Implementation of perform method. 
	 * */
	public void perform() {
		
		String outString= "Name of song is:"+ song;
		
		System.out.println(outString);
		//return outString;
	}

}
