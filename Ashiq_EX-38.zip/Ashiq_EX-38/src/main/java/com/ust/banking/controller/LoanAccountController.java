/**
 * Name: LoanAccountController
 * Descriptions: LoanAccountController class is controller class. 
 * Date: 22/10/2020
 */

package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.FDAccount;
import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.LoanAccountService;

/**
 * This controller class contains a method to return all the loan accounts.
 */
@RestController
public class LoanAccountController {

	@Autowired
	LoanAccountService loanAccountService;

	/**
	 * This method will returns all Loan accounts.
	 */
	@RequestMapping(value = "/loanaccount", method = RequestMethod.GET)
	public List<LoanAccount> getAllLoanAccount() {

		List<LoanAccount> listOfLoanAccounts = loanAccountService.getAllLoanAccount();

		return listOfLoanAccounts;
	}

	/**
	 * this method is to get one account by number
	 * */
	@RequestMapping(value = "/loanaccount/{number}", method = RequestMethod.GET)
	public LoanAccount getOneLoanAccountByNumber(@PathVariable int number) {

		LoanAccount loanAccount = loanAccountService.getLoanAccountByNumber(number);

		return loanAccount;
	}

	/**
	 * This method will update the account details.
	 */
	@RequestMapping(value = "/loanaccount/{number}", method = RequestMethod.PUT)
	public LoanAccount updateLoanAccount(@PathVariable int number, @RequestBody LoanAccount loanAccount) {

		if (loanAccountService.getLoanAccountByNumber(number) != null) {
			loanAccountService.updateAccount(loanAccount);

			return loanAccount;
		}
		return null;
	}

	@RequestMapping(value = "/loanaccount/{number}", method = RequestMethod.DELETE)
	public boolean deleteOneLoanAccountByNumber(@PathVariable int number) {

		if (loanAccountService.getLoanAccountByNumber(number) != null) {
			loanAccountService.deleteOneAccount(number);
			return true;
		}

		return false;
	}

	/**
	 * This method will add loan account
	 */
	@RequestMapping(value = "/loanaccount", method = RequestMethod.POST)
	public String addLoanAccount(@RequestBody LoanAccount loanAccount) {

		if (loanAccountService.getLoanAccountByNumber(loanAccount.getAccountNumber()) == null) {
			loanAccountService.addLoanAccount(loanAccount);
			return "Account added";

		}
		return "Account already exist";

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	*//**
		 * This method will returns all the loan accounts sort by name.
		 */
	/*
	 * @RequestMapping("/getAllLoanAccountSortByName") public String
	 * getAllLoanAccountSortByName(Model model) {
	 * 
	 * List<LoanAccount> listOfLoanAccounts=
	 * loanAccountService.getAllLoanAccountSortedByName();
	 * model.addAttribute("loanAccount", listOfLoanAccounts); return
	 * "redirect:/getAllLoanAccount"; }
	 * 
	 * 
	 *//**
		 * This method will returns all the loan accounts sort by amount
		 */
	/*
	 * @RequestMapping("/getAllLoanAccountSortByAmount") public String
	 * getAllLoanAccountSortByAmount(Model model) {
	 * 
	 * List<LoanAccount> listOfLoanAccounts=
	 * loanAccountService.getAllLoanAccountSortedByAmount();
	 * model.addAttribute("loanAccount", listOfLoanAccounts); return
	 * "redirect:/getAllLoanAccount"; }
	 * 
	 * 
	 *//**
		 * This method will update the account details.
		 */
	/*
	 * @RequestMapping("/updateLoanAccount") public String
	 * updateLoanAccount(@ModelAttribute("loanAccount") LoanAccount loanAccount) {
	 * 
	 * loanAccountService.updateAccount(loanAccount); return
	 * "redirect:/getAllLoanAccount"; }
	 * 
	 *//**
		 * This method is to show the Loan account form
		 */
	/*
	 * @RequestMapping("/showLoanAccountForm") public String
	 * showLoanAccountForm(Model model) {
	 * 
	 * LoanAccount loanAccount= new LoanAccount(); model.addAttribute("key",
	 * loanAccount); return "addLoanAccountForm";
	 * 
	 * }
	 *//**
		 * This method will add Loan account
		 */
	/*
	 * @RequestMapping("/addLoanAccount") public String
	 * addLoanAccount(@ModelAttribute("loanAccount") LoanAccount loanAccount){
	 * 
	 * loanAccountService.addLoanAccount(loanAccount); return
	 * "redirect:/getAllLoanAccount";
	 * 
	 * }
	 * 
	 * 
	 * 
	 *//**
		 * This method will returns all the loan accounts to a jsp page.
		 */
	/*
	 * @RequestMapping("/getAllLoanAccount") public String getAllLoanAccount(Model
	 * model) {
	 * 
	 * List<LoanAccount> listOfLoanAccounts= loanAccountService.getAllLoanAccount();
	 * model.addAttribute("loanAccount", listOfLoanAccounts); return
	 * "showAllLoanAccounts"; }
	 *//**
		 * This method will return one loan account
		 */
	/*
	 * @RequestMapping("/getOneLoanAccount") public String
	 * getOneLoanAccountByNumber(@RequestParam("number") String number, Model model)
	 * {
	 * 
	 * LoanAccount loanAccount=
	 * loanAccountService.getLoanAccountByNumber(Integer.parseInt(number));
	 * model.addAttribute("key", loanAccount); return "viewOneLoanAccount"; }
	 *//**
		 * This method will delete one Loan account
		 *//*
			 * @RequestMapping("/deleteOneLoanAccount") public String
			 * deleteOneLoanAccountByNumber(@RequestParam("number") String number, Model
			 * model) {
			 * 
			 * loanAccountService.deleteOneAccount(Integer.parseInt(number));
			 * 
			 * return "redirect:/getAllLoanAccount"; }
			 */
}
