/**
 * Name: LoanAccountDAO
 * Description: This is interface for Loan Account.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.LoanAccount;

/**
 * LoanAccountDAO interface contains methods for get all loan accounts, 
 * get one loan account by account number and delete one loan account.
 * 
 */
public interface LoanAccountDAO {
	
	/**Method is for get all loan accounts*/
	public List<LoanAccount> getAllLoanAccount();
	
	/**Method is for get one loan account by account number*/
	public LoanAccount getLoanAccountByNumber(int accountNumber);
	
	/**Method is for delete one loan account*/
	public boolean deleteOneLoanAccountById(int accountNumber);
}
