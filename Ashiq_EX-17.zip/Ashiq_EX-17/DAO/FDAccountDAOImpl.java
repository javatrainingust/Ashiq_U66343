/**
 * Name: FDAccountDAOImpl
 * Description: This is implementation for FDAccountDAO interface.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ust.banking.Entity.FDAccount;
/**
 * FDAccountDAOImpl contains implementation methods for FDAccountDAO interface.
 * 
 */
public class FDAccountDAOImpl implements FDAccountDAO {
	
	List<FDAccount> fdAccountList;
	
	/**Constructor for FDAccountDAOImpl*/
	public  FDAccountDAOImpl() {
		
		fdAccountList = new ArrayList<FDAccount>();
		FDAccount fdAccount1=new FDAccount(1111, "FDHolderNameB", 1, false, 500);
		FDAccount fdAccount2=new FDAccount(2222, "FDHolderNameA", 4, true, 100);
		FDAccount fdAccount3=new FDAccount(3333, "FDHolderNameC", 5, true,5000);
		FDAccount fdAccount4=new FDAccount(4444, "FDHolderNameD", 6, false,3000);
		
		fdAccountList.add(fdAccount1);
		fdAccountList.add(fdAccount2);
		fdAccountList.add(fdAccount3);
		fdAccountList.add(fdAccount4);
	}
	/**Method is for get all FD accounts*/
	@Override
	public List<FDAccount> getAllFdAccount() {
		// TODO Auto-generated method stub
		return fdAccountList;
	}
	
	/**Method is for get one FD account by account number*/
	@Override
	public FDAccount getFDAAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		FDAccount fdAccount= null;
		Iterator<FDAccount> iterator= fdAccountList.iterator();
		while (iterator.hasNext()) {
			FDAccount fdAccount2 =iterator.next();
			if(fdAccount2.getAccountNumber()==accountNumber) {
				fdAccount=fdAccount2;
			}
			
		}
		return fdAccount;
	}
	
	/**Method is for delete one FD account*/
	@Override
	public boolean deleteOneAccount(int accountNumber) {
		// TODO Auto-generated method stub
		for (FDAccount fdAccount : fdAccountList) {
			if (fdAccount.getAccountNumber()==accountNumber) {
				fdAccountList.remove(fdAccount);
				return true;
			}
		}
		return false;
	}

}
