/**
 * Name: CurrentAccountDAOImpl
 * Description: This is implementation for CurrentAccountDAO interface.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.List;

import com.ust.banking.Entity.CurrentAccount;

/**
 * CurrentAccountDAOImpl contains implementation methods for CurrentAccountDAO interface.
 * 
 */
public class CurrentAccountDAOImpl implements CurrentAccountDAO{
	
	List<CurrentAccount> currentAccountList;
	
	
	/** Constructor for CurrentAccountDAOImpl class*/	
	public CurrentAccountDAOImpl() {
		currentAccountList= new ArrayList<>();
		CurrentAccount currentAccount1 = new CurrentAccount(11131, "CurrentAccountHolder A", 50000);
		CurrentAccount currentAccount2 = new CurrentAccount(11132, "CurrentAccountHolder D", 5000);
		CurrentAccount currentAccount3 = new CurrentAccount(11133, "CurrentAccountHolder B", 110000);
		CurrentAccount currentAccount4 = new CurrentAccount(11134, "CurrentAccountHolder C", 1000);
		currentAccountList.add(currentAccount1);
		currentAccountList.add(currentAccount2);
		currentAccountList.add(currentAccount3);
		currentAccountList.add(currentAccount4);
		
	}
	/**Method is for get all current account*/
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}
	
	/**Method is for get one current account by account number*/
	@Override
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			return currentAccount;
		}
		return null;
	}
	/**Method is for delete one current account*/
	@Override
	public boolean deleteOneCurrentAccountById(int accountNumber) {
	
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			currentAccountList.remove(currentAccount);
			return true;
		}
		return false;
	}

}
