/**
 * Name: LonaAccountDAOImpl
 * Description: This is implementation for LoanAccountDAO interface.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.List;

import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.LoanAccount;
/**
 * LoanAccountDAOImpl contains implementation methods for FDAccountDAO interface.
 * 
 */
public class LoanAccountDAOImpl implements LoanAccountDAO{
	
	List<LoanAccount> loanAccountList;
	
	/**Constructor for LoanAccountDAOImpl*/
	public LoanAccountDAOImpl() {
		loanAccountList= new ArrayList<>();
		LoanAccount loanAccount1 = new LoanAccount(11141, "Loan Account Holder A", 500, 10000, 3);
		LoanAccount loanAccount2 = new LoanAccount(11142, "Loan Account Holder C", 5000,210000, 5);
		LoanAccount loanAccount3 = new LoanAccount(11143, "Loan Account Holder B", 100, 20000, 30);
		LoanAccount loanAccount4 = new LoanAccount(11144, "Loan Account Holder D", 500, 10000, 3);
		loanAccountList.add(loanAccount1);
		loanAccountList.add(loanAccount2);
		loanAccountList.add(loanAccount3);
		loanAccountList.add(loanAccount4);
		
	}
	/**Method is for get all loan accounts*/
	@Override
	public List<LoanAccount> getAllLoanAccount() {
		// TODO Auto-generated method stub
		return loanAccountList;
	}
	
	/**Method is for get one loan account by account number*/
	@Override
	public LoanAccount getLoanAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		for (LoanAccount loanAccount : loanAccountList) {
			if(loanAccount.getAccountNumber()==accountNumber);
			return loanAccount;
		}
		return null;
	}
	
	/**Method is for delete one loan account*/
	@Override
	public boolean deleteOneLoanAccountById(int accountNumber) {
		// TODO Auto-generated method stub
		for (LoanAccount loanAccount : loanAccountList) {
			if(loanAccount.getAccountNumber()==accountNumber);
			loanAccountList.remove(loanAccount);
			return true;
		}
		return false;
	}

}
