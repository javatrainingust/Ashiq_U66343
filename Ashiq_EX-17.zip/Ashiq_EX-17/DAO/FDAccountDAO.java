/**
 * Name: FDAccountDAO
 * Description: This is interface for FD Account.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.FDAccount;
/**
 * FDAccountDAO interface contains methods for get all FD accounts, 
 * get one FD account by account number and delete one FD account
 *
 */
public interface FDAccountDAO {
	/**Method is for get all FD accounts*/
	public List<FDAccount> getAllFdAccount();
	
	/**Method is for get one FD account by account number*/
	public FDAccount getFDAAccountByNumber(int accountNumber);
	
	/**Method is for delete one FD account*/
	public boolean deleteOneAccount(int accountNumber);
}
