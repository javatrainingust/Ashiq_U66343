/**
 * Name: SBAccountDAO
 * Description: This is interface for SB Account.
 * Date: 07/10/2020
 */
package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.SBAccount;

/**
 * SBAccountDAO interface contains methods for get all SB accounts, get one SB account by account number and 
 * delete one SB account.
 */

public interface SBAccountDAO {
	
	/**Method is for get all SB accounts*/
	public List<SBAccount> getAllSBAccount();
	
	/**Method is for get one SB account by account number*/
	public SBAccount getSBAAccountByNumber(int accountNumber);
	
	/**Method is for delete one SB account*/
	public boolean deleteOneSBAccountById(int accountNumber);
}
