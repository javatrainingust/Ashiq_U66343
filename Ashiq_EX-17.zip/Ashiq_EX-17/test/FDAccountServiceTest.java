/**
 * Name: FDAccountServiceTest
 * Descriptions: FDAccountServiceTest class is for testing FDAccountService class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.Entity.FDAccount;
import com.ust.banking.service.FDAccountService;

/**
 * This class contains testing methods get all FD account sorted by name and get
 * all FD account sorted by Balance.
 * 
 */
class FDAccountServiceTest {

	List<FDAccount> list;

	/** Constructor for FDAccountServiceTest */

	public FDAccountServiceTest() {

		list = new ArrayList<>();
		FDAccount fdAccount1 = new FDAccount(1111, "FDHolderNameB", 1, false, 500);
		FDAccount fdAccount2 = new FDAccount(2222, "FDHolderNameA", 4, true, 100);
		FDAccount fdAccount3 = new FDAccount(3333, "FDHolderNameC", 5, true, 5000);
		FDAccount fdAccount4 = new FDAccount(4444, "FDHolderNameD", 6, false, 3000);
		list.add(fdAccount1);
		list.add(fdAccount2);
		list.add(fdAccount3);
		list.add(fdAccount4);

	}

	/** Method is test for get all FD account sorted by name */
	@Test
	void testGetAllFDAccountSortedByName() {

		List<String> expectedListOfName = new ArrayList<>();
		for (FDAccount fdAccount : list) {
			expectedListOfName.add(fdAccount.getAccountHolderName());
		}
		Collections.sort(expectedListOfName);

		FDAccountService fdAccountService = new FDAccountService();
		List<FDAccount> actual = fdAccountService.getAllFDAccountSortedByName();
		List<String> actualListOfName = new ArrayList<>();
		for (FDAccount fdAccount : actual) {
			actualListOfName.add(fdAccount.getAccountHolderName());
		}
		assertEquals(expectedListOfName, actualListOfName);

	}

	/** Method is test for get all FD account sorted by balance */
	@Test
	void testGetAllFDAccountSortedByBalance() {

		List<Float> expectedListOfBalance = new ArrayList<>();
		for (FDAccount fdAccount : list) {
			expectedListOfBalance.add(fdAccount.getFDBalance());
		}
		Collections.sort(expectedListOfBalance);

		FDAccountService fdAccountService = new FDAccountService();
		List<FDAccount> actual = fdAccountService.getAllFDAccountSortedByBalance();
		List<Float> actualListOfBalace = new ArrayList<>();

		for (FDAccount fdAccount : actual) {
			actualListOfBalace.add(fdAccount.getFDBalance());
		}
		assertEquals(expectedListOfBalance, actualListOfBalace);
	}

}
