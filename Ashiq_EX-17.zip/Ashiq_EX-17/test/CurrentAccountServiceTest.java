/**
 * Name: CurrentAccountServiceTest
 * Descriptions: CurrentAccountServiceTest class is for testing CurrentAccountService class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.Entity.CurrentAccount;

import com.ust.banking.service.CurrentAccountService;

/**
 * This class contains testing methods get all current account sorted by name and
 * get all current account sorted by Overdraft Limit.
 * 
 */
class CurrentAccountServiceTest {

	List<CurrentAccount> currentAccountList;

	/** Constructor for CurrentAccountServiceTest */

	public CurrentAccountServiceTest() {
		currentAccountList = new ArrayList<>();
		CurrentAccount currentAccount1 = new CurrentAccount(11131, "CurrentAccountHolder A", 50000);
		CurrentAccount currentAccount2 = new CurrentAccount(11132, "CurrentAccountHolder D", 5000);
		CurrentAccount currentAccount3 = new CurrentAccount(11133, "CurrentAccountHolder B", 110000);
		CurrentAccount currentAccount4 = new CurrentAccount(11134, "CurrentAccountHolder C", 1000);
		currentAccountList.add(currentAccount1);
		currentAccountList.add(currentAccount2);
		currentAccountList.add(currentAccount3);
		currentAccountList.add(currentAccount4);

	}

	/** Method is test for get all current account sorted by name */
	@Test
	void testGetAllCurrentAccountSortedByName() {

		List<String> expectedListOfName = new ArrayList<>();
		for (CurrentAccount currentAccount : currentAccountList) {
			expectedListOfName.add(currentAccount.getAccountHolderName());
		}
		Collections.sort(expectedListOfName);

		CurrentAccountService currentAccountService = new CurrentAccountService();
		List<CurrentAccount> actual = currentAccountService.getAllCurrentAccountSortedByName();
		List<String> actualListOfName = new ArrayList<>();
		for (CurrentAccount currentAccount : actual) {
			actualListOfName.add(currentAccount.getAccountHolderName());
		}
		assertEquals(expectedListOfName, actualListOfName);
	}

	/** Method is test for get all current account sorted by overdraft limit */
	@Test
	void testGetAllCurrentAccountSortedByOverdraftLimit() {

		List<Float> expectedListOfOverdraftLimit = new ArrayList<>();
		for (CurrentAccount currentAccount : currentAccountList) {
			expectedListOfOverdraftLimit.add(currentAccount.getOverDraftLimit());
		}
		Collections.sort(expectedListOfOverdraftLimit);

		CurrentAccountService currentAccountService = new CurrentAccountService();
		List<CurrentAccount> actual = currentAccountService.getAllCurrentAccountSortedByOverdraftLimit();
		List<Float> actualListOfOverdraftLimit = new ArrayList<>();

		for (CurrentAccount currentAccount : actual) {
			actualListOfOverdraftLimit.add(currentAccount.getOverDraftLimit());
		}
		assertEquals(expectedListOfOverdraftLimit, actualListOfOverdraftLimit);
	}

}
