/**
 * Name: FDAccountDAOImplTest
 * Descriptions: FDAccountDAOImplTest class is for testing FDAccountDAOImpl class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.DAO.FDAccountDAOImpl;

import com.ust.banking.Entity.FDAccount;
/**
 * This is JUnit Test for FD AccountDAOImpl
 * 
 */
class FDAccountDAOImplTest {
	
	
	List<FDAccount> listExpected;
	/**Constructor for FDAccountDAOImplTest*/
	public FDAccountDAOImplTest() {
		
		
		listExpected= new ArrayList<>();
		FDAccount fdAccount1=new FDAccount(1111, "FDHolderNameB", 1, false, 500);
		FDAccount fdAccount2=new FDAccount(2222, "FDHolderNameA", 4, true, 100);
		FDAccount fdAccount3=new FDAccount(3333, "FDHolderNameC", 5, true,5000);
		FDAccount fdAccount4=new FDAccount(4444, "FDHolderNameD", 6, false,3000);
		listExpected.add(fdAccount1);
		listExpected.add(fdAccount2);
		listExpected.add(fdAccount3);
		listExpected.add(fdAccount4);
		
	}
	

	/**Test for Get all FD account*/
	
	@Test
	void testGetAllFdAccount() {
		FDAccountDAOImpl fdAccountDAOImpl=new FDAccountDAOImpl();
		List<FDAccount> actualList= fdAccountDAOImpl.getAllFdAccount();
		assertEquals(listExpected.size(), actualList.size());

	}

	/**test for get one FD account by ID*/
	  @Test 
	  void testGetFDAAccountByNumber() {
		  FDAccountDAOImpl fdAccountDAOImpl=new FDAccountDAOImpl();
		  String expected= listExpected.get(0).getAccountHolderName();
		  String actual= fdAccountDAOImpl.getFDAAccountByNumber(1111).getAccountHolderName();
		  assertEquals(expected, actual);
		  
		  
	  }
	  /**test for delete one FD account by id*/
	  @Test 
	  void testDeleteOneAccount() { 
		 FDAccountDAOImpl fdAccountDAOImpl= new FDAccountDAOImpl();
		 
		assertNotNull(fdAccountDAOImpl.getFDAAccountByNumber(1111));
		assertTrue(fdAccountDAOImpl.deleteOneAccount(1111));
		assertNull(fdAccountDAOImpl.getFDAAccountByNumber(1111));
		
		  
	  }
	 
}
