/**
 * The class "Account" will be acting as the data model for the Account. 
 * Date: 30/09/2020
 */


package com.ust.banking.Entity;

/**
 * This class  have two fields (accountNumber,accountHolderName)
 */

public class Account {

	private int accountNumber;
	private String accountHolderName;
	/**No argument constructor for Account class*/
	public Account() {
		
	}
	/**Argument constructor for Account class*/
	public Account(int accountNumber, String accountHolderName) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		
		
	}

	private float balance=10000;
	
	/** Accessor method for account number*/
	public int getAccountNumber() {
		return accountNumber;
	}
	/** Setter method for account number*/
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	/* Accessor method for accountHolderName*/
	public String getAccountHolderName() {
		return accountHolderName;
	}
	/* Setter method for accountHolderName*/
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	/* Accessor method for balance*/
	public float getBalance() {
		return balance;
	}
	/*Method for withdraw Money*/
	public float withdrawMoney(float amount) {
		this.balance=balance-amount;
		return balance;
	}
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName + ", balance="
				+ balance + "]";
	}

	
}
