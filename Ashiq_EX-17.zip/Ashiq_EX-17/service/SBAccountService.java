/**
 * Name:SBAccountService
 * Descriptions: SBAccountService is for writing business logics for SB Account
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;

import com.ust.banking.DAO.SBAccountDAO;
import com.ust.banking.DAO.SBAccountDAOImpl;
import com.ust.banking.Entity.SBAccount;

/**
 * This class contains methods get all SB account, get one SB account by account
 * number SB outstanding, delete one SB account, get all SB account sorted by
 * name, get all SB account sorted by balance.
 * 
 */
public class SBAccountService {
	SBAccountDAO sbAccountDAO;

	/** Constructor for SBAccountService */
	public SBAccountService() {
		sbAccountDAO = new SBAccountDAOImpl();
	}

	/** Method is for get all SB accounts */
	public List<SBAccount> getAllSBAccount() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		for (SBAccount sbAccount : accounts) {
			System.out.println(sbAccount.getAccountNumber());
			System.out.println(sbAccount.getAccountHolderName());
			System.out.println(sbAccount.getBalance());
			System.out.println(sbAccount.getMinimumBalance());
		}
		return accounts;
	}

	/** Method is for get one SB account by account number */
	public SBAccount getSBAccountByNumber(int accountNumber) {

		SBAccount account = sbAccountDAO.getSBAAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getSBBalance());
		System.out.println(account.getMinimumBalance());
		return account;
	}

	/** Method is for delete one SB account */
	public boolean deleteOneAccount(int accountNumber) {

		return sbAccountDAO.deleteOneSBAccountById(accountNumber);
	}

	/** Method is for get all SB accounts sorted by name */
	public List<SBAccount> getAllSBAccountSortedByName() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		Collections.sort(accounts);
		for (SBAccount sbAccount : accounts) {
			System.out.println(sbAccount.getAccountNumber());
			System.out.println("Name: " + sbAccount.getAccountHolderName());
			System.out.println(sbAccount.getSBBalance());
			System.out.println(sbAccount.getMinimumBalance());
		}
		return accounts;
	}

	/** Method is for get all SB accounts sorted by balance */
	public List<SBAccount> getAllSBAccountSortedByBalance() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		Collections.sort(accounts, new SBSortedBalance());
		for (SBAccount sbAccount : accounts) {
			System.out.println(sbAccount.getAccountNumber());
			System.out.println("Name: " + sbAccount.getAccountHolderName());
			System.out.println("Balance: " + sbAccount.getSBBalance());
			System.out.println(sbAccount.getMinimumBalance());
		}
		return accounts;
	}
}
