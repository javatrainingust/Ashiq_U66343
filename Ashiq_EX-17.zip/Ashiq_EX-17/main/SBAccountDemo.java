/**
 * Name: SBAccountDemo
 * Description: This is demo class for SBAccount.
 * Date: 06/10/2020
 */

package com.ust.banking.main;

import com.ust.banking.service.SBAccountService;
/**
 *This class is for display outputs. 
 */
public class SBAccountDemo {

	/**Main method*/
	public static void main(String[] args) {
		
		SBAccountService sbAccountService= new SBAccountService();
		System.out.println("========List of all SB Accounts=============");
		sbAccountService.getAllSBAccount();
		/*
		 * System.out.
		 * println("=========One particular SB account by Account number===========");
		 * sbAccountService.getSBAccountByNumber(11112);
		 * System.out.println("=============Delete status============");
		 * System.out.println(sbAccountService.deleteOneAccount(11113));
		 */
		System.out.println("========List of all SB Accounts By Name=============");
		sbAccountService.getAllSBAccountSortedByName();
		System.out.println("========List of all SB Accounts By Name=============");
		sbAccountService.getAllSBAccountSortedByBalance();
	}

}
