/**
 * Name: CurrentAccountDemo
 * Description: This is demo class for CurrentAccount.
 * Date: 06/10/2020
 */

package com.ust.banking.main;

import com.ust.banking.service.CurrentAccountService;

/**CurrentAccountDemo class is for display outputs */
public class CurrentAccountDemo {
	
	/**
	 * main method 
	 * 
	 * */
	public static void main(String[] args) {
		
		CurrentAccountService currentAccountService= new CurrentAccountService();
		System.out.println("========List of all Current Accounts=============");
		currentAccountService.getAllCurrentAccount();
		/*
		 * System.out.
		 * println("=========One particular Current account by Account number==========="
		 * ); currentAccountService.getCurrentAccountByNumber(11131);
		 * System.out.println("=============Delete status============");
		 * System.out.println(currentAccountService.deleteOneAccount(11132));
		 */
		
		System.out.println("========List of all Current Accounts sorted by name=============");
		currentAccountService.getAllCurrentAccountSortedByName();
		System.out.println("========List of all Current Accounts sorted by overdraft limit=============");
		currentAccountService.getAllCurrentAccountSortedByOverdraftLimit();
	}

}
