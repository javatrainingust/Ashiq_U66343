/**
 * Name: CurrentAccountController
 * Descriptions: CurrentAccountController class is controller class. 
 * Date: 15/10/2020
 */

package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.FDAccount;
import com.ust.banking.service.CurrentAccountService;

/**
 * This controller class contains a method to get all current accounts. 
 * */
@Controller
public class CurrentAccountController {

	@Autowired
	CurrentAccountService currentAccountService;
	
	/**
	 * This method is to show the Current account form
	 * */
	@RequestMapping("/showCurrentAccountForm")
	public String showCurrentAccountForm(Model model) {
		
		CurrentAccount currentAccount= new CurrentAccount();
		model.addAttribute("key", currentAccount);
		return "addCurrentAccountForm";
		
	}
	/**
	 * This method will add current account
	 * */
	@RequestMapping("/addCurrentAccount")
	public String addCurrentAccount(@ModelAttribute("currentAccount") CurrentAccount currentAccount){
		
		currentAccountService.addCurrentAccount(currentAccount);
		return "redirect:/getAllCurrentAccount";
		
	} 
	
	
	/**
	 * This method will return all the current accounts to a jsp page. 
	 * */
	@RequestMapping("/getAllCurrentAccount")
	public String getAllCurrentAccount(Model model) {
		
		List<CurrentAccount> listOfCurrentAccounts= currentAccountService.getAllCurrentAccount();
		model.addAttribute("currentAccount", listOfCurrentAccounts);
		return "showAllCurrentAccounts";
	}
	/**
	 * This method will return one current account
	 * */
	@RequestMapping("/getOneCurrentAccount")
	public String getOneCurrentAccountByNumber(@RequestParam("number") String number, Model model) {
		
		CurrentAccount currentAccount= currentAccountService.getCurrentAccountByNumber(Integer.parseInt(number));
		model.addAttribute("key", currentAccount);
		return "viewOneCurrentAccount";
	}
	/**
	 * This method will delete one current account
	 * */
	@RequestMapping("/deleteOneCurrentAccount")
	public String deleteOneCurrentAccountByNumber(@RequestParam("number") String number, Model model) {
		
		currentAccountService.deleteOneAccount(Integer.parseInt(number));
		
		return "redirect:/getAllCurrentAccount";
	}
}
