/**
 * Name: SBAccountController
 * Descriptions: SBAccountController class is controller class. 
 * Date: 15/10/2020
 */


package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.SBAccountService;

/**
 * This controller class contains a method , it returns all SB accounts. 
 * */
@Controller
public class SBAccountController {
	@Autowired
	SBAccountService sbAccountService;
	
	
	/**
	 * This method is to show the SB account form
	 * */
	@RequestMapping("/showSBAccountForm")
	public String showSBAccountForm(Model model) {
		
		SBAccount sbAccount= new SBAccount();
		model.addAttribute("key", sbAccount);
		return "addSBAccountForm";
		
	}
	/**
	 * This method will add SB account
	 * */
	@RequestMapping("/addSBAccount")
	public String addSBAccount(@ModelAttribute("sbAccount") SBAccount sbAccount){
		
		sbAccountService.addSBAccount(sbAccount);
		return "redirect:/getAllSBAccount";
		
	} 
	
	
	/**
	 * This method will returns all SB accounts to jsp page. 
	 * */
	@RequestMapping("/getAllSBAccount")
	public String getAllSBAccount(Model model) {
		
		List<SBAccount> listOfSbAccounts= sbAccountService.getAllSBAccount();
		model.addAttribute("sbAccount", listOfSbAccounts);
		return "showAllSBAccounts";
	}
	/**
	 * This method will return one SB account
	 * */
	@RequestMapping("/getOneSBAccount")
	public String getOneSBAccountByNumber(@RequestParam("number") String number, Model model) {
		
		SBAccount sbAccount= sbAccountService.getSBAccountByNumber(Integer.parseInt(number));
		model.addAttribute("key", sbAccount);
		return "viewOneSBAccount";
	}
	/**
	 * This method will delete one SB account
	 * */
	@RequestMapping("/deleteOneSBAccount")
	public String deleteOneSBAccountByNumber(@RequestParam("number") String number, Model model) {
		
		sbAccountService.deleteOneAccount(Integer.parseInt(number));
		
		return "redirect:/getAllSBAccount";
	}
}
