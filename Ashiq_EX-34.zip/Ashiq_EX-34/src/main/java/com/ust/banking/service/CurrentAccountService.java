/**
 * Name: CurrentAccountService
 * Descriptions: CurrentAccountService class is the service class contains business logics for Current account. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.ust.banking.DAO.CurrentAccountDAO;
import com.ust.banking.DAO.CurrentAccountDAOImpl;
import com.ust.banking.Entity.CurrentAccount;


/**
 * This class contains methods get all current account, get one current account by account number,
 * delete one current account, get all current account sorted by name, get all current account sorted by Overdraft Limit
 * 
 */
@Service
public class CurrentAccountService {

CurrentAccountDAO currentAccountDAO;
	
	public CurrentAccountService() {
		currentAccountDAO= new CurrentAccountDAOImpl();
	}
	
	/**Method is for get all current account*/
	public List<CurrentAccount> getAllCurrentAccount() {
		
		List<CurrentAccount> accounts= currentAccountDAO.getAllCurrentAccount();
		
		return accounts;
	}
	
	/**Method is for get one current account by account number*/
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		
		CurrentAccount account= currentAccountDAO.getCurrentAccountByNumber(accountNumber);
		
		return account;
	}
	
	/**Method is for delete one current account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return currentAccountDAO.deleteOneCurrentAccountById(accountNumber);
	}
	
	
	
	
	/**Method to add one Current account*/
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		if (currentAccountDAO.addCurrentAccount(currentAccount)) {
			System.out.println("Account added suceessfully- Account number : "+currentAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one Current account*/
	public boolean updateAccount(CurrentAccount currentAccount) {
		if (currentAccountDAO.updateCurrentAccount(currentAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
}
