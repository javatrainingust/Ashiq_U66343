/**
 * Name: AboutMeController
 * Description: AboutMeController is the demo controller class
 * Date: 14/10/2020
 * */

package com.ust.springmvc.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * This is demo controller class
 * */
@Controller
public class AboutMeController {
	/**
	 * This method will render the page hobbies.jsp
	 * */
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		
		return "aboutMe";
	}
	/**
	 * This method accepts a request parameter and add with with a string. 
	 * */
	@RequestMapping("/processForms")
	public String process(@RequestParam("hobby") String hobby,  Model model) {
		
		String result="My hobby is: "+hobby;
		model.addAttribute("message", result);
		return "myHobbies";
		
	}
}
