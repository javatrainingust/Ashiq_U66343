/**
 * Name: SignUpController
 * Description: SignUpController is the controller class
 * Date: 14/10/2020
 * */

package com.ust.springmvc.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ust.springmvc.model.Signup;

/**
 * This is demo controller class
 * */
@Controller
public class SignUpController {
	
	/**
	 * This method is to show form
	 * */
	@RequestMapping("/showForm")
	public String showForm(Model model) {
		Signup signup= new Signup();
		model.addAttribute("signup", signup);
		return "signup";
	}
	/**
	 * This method will process the form data and returns to a jsp page using model atribute. 
	 * */
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("signup") Signup signup) {
		System.out.println(signup.getUserName());
		return "confirmSignup";
	}
}
