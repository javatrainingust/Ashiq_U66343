package com.ust.demo.lambda;

public interface Test {

	public void test();
}
