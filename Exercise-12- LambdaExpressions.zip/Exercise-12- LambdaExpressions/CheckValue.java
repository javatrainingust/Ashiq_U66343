package com.ust.demo.lambda;

public interface CheckValue {

	public boolean check(int n);
}
