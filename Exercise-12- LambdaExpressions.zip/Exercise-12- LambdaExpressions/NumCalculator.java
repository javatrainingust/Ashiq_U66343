package com.ust.demo.lambda;

public interface NumCalculator {

	public int getValue(int a, int b);
}
