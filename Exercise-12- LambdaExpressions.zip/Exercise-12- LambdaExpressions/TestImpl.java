package com.ust.demo.lambda;

public class TestImpl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CheckValue checkValue= (n)->(n%2)==0;
		System.out.println(checkValue.check(10));
		
		NumCalculator numCalculator=(a,b)->a+b;
		System.out.println(numCalculator.getValue(3, 5));
		
		DisplayResult displayResult =(s)->System.out.println(s);
		displayResult.display("String is passed");
		
		Test test=()->System.out.println("Test interface");
		test.test();
	}

}