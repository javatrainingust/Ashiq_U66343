package com.ust.demo.lambda;

public interface DisplayResult {
	
	public void display(String string);
}
