package com.ust.banking.Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


/** This is test for LoanAccount class
 * Date: 01/10/2020*/
class LoanAccountTest {

	/*This method will test the testCalcEmi method*/
	@Test
	void testCalcEmi() {
		
		LoanAccount loanAccount= new LoanAccount();
		float expected = 37500.0f;
		float actual= loanAccount.calcEmi(2, 50000);
		assertEquals(expected, actual);
	}

}
