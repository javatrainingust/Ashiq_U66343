package com.ust.banking.Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ust.banking.util.ICalculator;
import com.ust.banking.util.InterestCalculator;

/** This is test for FDAccount class
 * Date: 01/10/2020*/
class FDAccountTest {

	/*This method will test the CalculateInterest method*/
	@Test
	void testCalculateInterest() {
		
		InterestCalculator interestCalculator= new InterestCalculator();
		FDAccount fdAccount=new FDAccount();
		float expected=18.000002f;
		float actual= fdAccount.calculateInterest(2, interestCalculator);
		assertEquals(expected, actual);
		
	}

	

}
