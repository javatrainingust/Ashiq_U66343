package com.ust.banking.Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/** This is test for account class
 * Date: 01/10/2020*/

class AccountTest {
	
	/*This method will test the withdrawMoney method*/
	@Test
	void testWithdrawMoney() {
		Account account=new Account();
		
		float actual= account.withdrawMoney(1000);
		float expected= 9000;
		assertEquals(expected, actual);
		
	}

}
