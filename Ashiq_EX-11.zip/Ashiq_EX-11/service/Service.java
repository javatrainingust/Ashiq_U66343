package com.ust.banking.service;


import java.time.LocalDate;

import com.ust.banking.Entity.Account;
import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.FDAccount;
import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.Renewable;
import com.ust.banking.Entity.SBAccount;
import com.ust.banking.util.InterestCalculator;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LoanAccount account=new LoanAccount();
		
		account.setAccountHolderName("Ashiq");
		account.setAccountNumber(1234);
		
		
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getAccountNumber());
		
		System.out.println("EMI is: "+account.calcEmi(12, 9000));
		
		CurrentAccount currentAccount= new CurrentAccount();
		
		System.out.println("Current account overdraft limit after withdrawal of 100: "+currentAccount.withdrawMoney(100));
		
		
		
		//EX-7(Interfaces)
		FDAccount fdAccount=new FDAccount();
		
		InterestCalculator interestCalculator=new InterestCalculator();
		fdAccount.calculateInterest(12,interestCalculator);
		
		
	}

}
