package com.ust.banking.util;
/*interface for calculating interest*/
public interface ICalculator {
	
	public float intrestCalculator( int duration,float amount);
	
}
