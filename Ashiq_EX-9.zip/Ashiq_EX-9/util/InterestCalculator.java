package com.ust.banking.util;

public class InterestCalculator implements ICalculator{

	private float fdRate= 0.09f;
	private float sbRate= 0.04f;
	
	//method for calculating SB account interest. 
	 public float intrestCalculator(float amount, int duration) {
		return sbRate*amount*duration/100;
	}
	/*method for calculating FD account interest. Here parameter order is different from above method. through this method overloading is atchiving. 
	This method is the implementation of interestCalculator method in the ICalculator interface */
	public float intrestCalculator(int duration, float amount) {
		return fdRate*amount*duration/100;
	}
}
