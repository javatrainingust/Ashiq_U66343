package com.ust.banking.Entity;

public class Account {

	private int accountNumber;
	private String accountHolderName;
	
	public Account() {
		System.out.println("This is from Account no arg construtor");
	}
	
	public Account(int accountNumber, String accountHolderName) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		
		System.out.println("This is from Account  arg construtor");
	}

	private float balance=10000;
	
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public float getBalance() {
		return balance;
	}
	
	public float withdrawMoney(float amount) {
		this.balance=balance-amount;
		return balance;
	}

	
}
