package com.ust.banking.Entity;

import com.ust.banking.util.InterestCalculator;

public class SBAccount extends Account {

	public SBAccount() {
		System.out.println("This is from SBAccount no arg construtor");
	}
	
	InterestCalculator interestCalculator=new InterestCalculator();
	public void calculateInterest(int duration) {
	float total=interestCalculator.intrestCalculator(getBalance(), duration);
		
		System.out.println("Interest from Chiled SBAccount :"+total);
	}
}
