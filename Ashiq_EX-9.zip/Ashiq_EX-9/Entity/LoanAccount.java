package com.ust.banking.Entity;

public class LoanAccount extends Account{
	
	private float emi;
	private float loanOutStanding;
	private int tenure;
	
	public LoanAccount() {}
	
	public LoanAccount(float emi, float loanOutStanding, int tenure) {
		super();
		this.emi = emi;
		this.loanOutStanding = loanOutStanding;
		this.tenure = tenure;
		System.out.println("This is from LoanAccount arg construtor");
	}

	public float calcEmi(int tenure, float loanAmount) {
		this.emi=(float) ((loanAmount/tenure)*1.5);
		return emi;
	} 

}
