/**
 * Name: StreamDemoOne
 * Description: StreamDemoOne class demonstrating the functionality of Stream. 
 * Date: 09/10/2020
 */

package com.ust.strams.demo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

/**
 * StreamDemoOne class contains the demonstration of Arrays.stream() and stream() methods. 
 * */
public class StreamDemoOne {

	/**
	 * Main method will take the count of students from an array list of students. Also converts a student array in to stream object.
	 * */
	public static void main(String[] args) {
		

		//Excercise-1
		
		List<String> students= new ArrayList<>();
		students.add("Vinod");
		students.add("Suresh");
		students.add("Jane");
		students.add("Roshan");
		
		Stream<String> streamStudents= students.stream();
		long count= streamStudents.count();
		System.out.println("Count of students is :"+count);
		
		//Excercise-2
		
		String [] student= {"Vinod","Suresh","Jane","Roshan"};
		Stream<String> streamStudent= Arrays.stream(student);
		
	}

}
