package com.ust.collections.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;



/**
 * This is main class. 
 * Date: 05/10/2020
 */
public class Main {
	
	/*main method*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> students= new ArrayList<>();
		students.add("Vivek");
		students.add("Vijay");
		students.add("Ajith");
		students.add("Surya");
		
		for (String student : students) {
			System.out.println(student);
		}
		
		List<Cat> cats=new ArrayList<>();
		Cat cat1=new Cat("Cat1", 2);
		Cat cat2=new Cat("Cat2", 20);
		Cat cat3=new Cat("Cat3", 10);
		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		
		Iterator<Cat> iterator=cats.iterator();
		while (iterator.hasNext()) {
			
			System.out.println(iterator.next());
		}
		Collections.sort(students);
		for (String student : students) {
			System.out.println(student);
		}
		Collections.sort(cats);
		System.out.println(cats);
	}

}
