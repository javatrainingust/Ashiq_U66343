package com.ust.collections.demo;


/**
 * The class "Cat" will be acting as the data model for the Cat. 
 * Date: 05/10/2020
 */
public class Cat implements Comparable<Cat>{

	private String name;
	private Integer age;
	
	/*This method will compare the cat object in terms of age*/
	@Override
	public int compareTo(Cat o) {
		// TODO Auto-generated method stub
		return age.compareTo(o.age);
	}
	
	/*Argument constructor for Cat*/
	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	/*toString method for printing cat object*/
	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}
	
	
}
