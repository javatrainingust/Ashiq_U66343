/**
 * Name: Cat
 * Description: Cat class is the model class for cat object. 
 * Date: 09/10/2020
 */

package com.ust.strams.demo;

/**
 * This class contains cat name and age as variables. Implements comparable interface for sorting. 
 * */
public class Cat implements Comparable<Cat>{

	private String name;
	private Integer age;
	
	/**This method will compare the cat object in terms of age*/
	@Override
	public int compareTo(Cat cat) {
		// TODO Auto-generated method stub
		return age.compareTo(cat.age);
	}
	
	/**Argument constructor for Cat*/
	public Cat(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	/**toString method for printing cat object*/
	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}
}
