/**
 * Name: CatMain
 * Description: CatMain class is the demo class for printing cat object. 
 * Date: 09/10/2020
 */

package com.ust.strams.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * This class contains the sorting of cat object based on  age
 * */
public class CatMain {
	
	/**
	 * main method creates few cat objects and adding that to an array list. and sorting using streams.
	 * */
	public static void main(String[] args) {
		
		List<Cat> catsList= new ArrayList<>();
		catsList.add(new Cat("Cat1", 10));
		catsList.add(new Cat("Cat2", 20));
		catsList.add(new Cat("Cat3", 5));
		catsList.add(new Cat("Cat4", 2));
		
		Stream<Cat> catStream= catsList.stream().sorted();
		
		catStream.forEach((e)->System.out.println(e));
	}

}
