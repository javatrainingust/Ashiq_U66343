/**
 * Name: StreamsDemoTwo
 * Description: StreamsDemoTwo class demonstrating the functionality of Stream, map, filter. 
 * Date: 09/10/2020
 */

package com.ust.strams.demo;

import java.util.stream.Stream;

/**
 * This class showing the functionality of stream, map, filter. 
 * */
public class StreamsDemoTwo {
	
	/**
	 * main method multiplies stream of integers in by 2 and filter the values greater than 10 and prints its count. 
	 * */
	public static void main(String[] args) {
		
		Stream<Integer> numbers= Stream.of(1,2,3,4,5,6,7,8,9);
		
		long count= numbers.map((e)->e*2).filter((n)->n>10).count();
		System.out.println(count);
		
		Stream<String> student= Stream.of("Vinod","Suresh","Jane","Roshan").sorted();
		
		student.forEach((e)->System.out.println(e));
		
	}

}
