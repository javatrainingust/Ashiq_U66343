/**
 * Name: AboutMeController
 * Description: AboutMeController is the demo controller class
 * Date: 
 * */

package com.ust.springmvc.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * This is demo controller class
 * */
@Controller
public class AboutMeController {
	/**
	 * This method will render the page hobbies.jsp
	 * */
	@RequestMapping("/hobbies")
	public String getMyHobbies() {
		
		return "hobbies";
	}
}
