/**
 * Name: OrganiserTest
 * Description: OrganiserTest is test class for organiser.  
 * Date:12/10/2020
 * 
 * */


package com.ust.competetion.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ust.competetion.bean.Organiser;

/**
 * This class is test class for organiser. 
 * */
public class OrganiserTest {

	/**
	 * This method will test sayGreetings method of organiser. 
	 * */
	@Test
	public void testSayGreetings() {
		Organiser organiser= new Organiser();
		
		String expected= "Welcome to the talent competion";
		String actual= organiser.sayGreetings();
		assertEquals(expected, actual);
	}

}
