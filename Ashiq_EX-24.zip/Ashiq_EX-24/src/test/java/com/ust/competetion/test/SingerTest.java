/**
 * Name: SingerTest
 * Description: SingerTest is test class for singer.  
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.ust.competetion.bean.Singer;

/**
 * This is test class for Singer
 * */
public class SingerTest {

	/**
	 * This method will test the perofrm method. 
	 * */
	@Test
	public void testPerform() {
		Singer singer= new Singer("Song name 1");
		String expected="Name of song is:Song name 1";
		String actual= singer.perform();
		assertEquals(expected, actual);
	}

}
