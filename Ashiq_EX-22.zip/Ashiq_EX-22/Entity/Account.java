/**
 * Name: Account
 * The class "Account" will be acting as the data model for the Account. 
 * Date: 30/09/2020
 */


package com.ust.banking.Entity;

/**
 * This class  have two fields (accountNumber,accountHolderName)
 */

public class Account {

	private int accountNumber;
	private String accountHolderName;
	/**No argument constructor for Account class*/
	public Account() {
		
	}
	/**Argument constructor for Account class*/
	public Account(int accountNumber, String accountHolderName) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		
		
	}
/**Overrided hashcode method for avoiding duplicates*/
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNumber;
		return result;
	}
	
	/**Overrided equals method for avoiding duplicates*/
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNumber != other.accountNumber)
			return false;
		return true;
	}

	private float balance=10000;
	
	/** Accessor method for account number*/
	public int getAccountNumber() {
		return accountNumber;
	}
	/** Setter method for account number*/
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	/** Accessor method for accountHolderName*/
	public String getAccountHolderName() {
		return accountHolderName;
	}
	/** Setter method for accountHolderName*/
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	/** Accessor method for balance*/
	public float getBalance() {
		return balance;
	}
	/**Method for withdraw Money*/
	public float withdrawMoney(float amount) {
		this.balance=balance-amount;
		return balance;
	}
	/**ToString method*/
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName + ", balance="
				+ balance + "]";
	}

	
}
