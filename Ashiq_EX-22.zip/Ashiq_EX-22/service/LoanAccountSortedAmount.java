/**
 * Name: LoanAccountSortedAmount 
 * Descriptions: LoanAccountSortedAmount class is for sorting loan account account in terms of loan outstanding amount. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Comparator;


import com.ust.banking.Entity.LoanAccount;

/**This class implements the compare method of Comparator interface*/

public class LoanAccountSortedAmount implements Comparator<LoanAccount>{

	/**Implementation for compare method*/
	@Override
	public int compare(LoanAccount account1, LoanAccount account2) {
		// TODO Auto-generated method stub
		return (int) (account1.getLoanOutStanding()-account2.getLoanOutStanding());
	}

}
