/**
 * Name: LoanAccountDAOImplTest
 * Descriptions: LoanAccountDAOImplTest class is for testing LoanAccountDAOImpl class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.DAO.LoanAccountDAOImpl;

import com.ust.banking.Entity.LoanAccount;

/**
 * This is JUnit Test for Loan AccountDAOImpl
 * 
 */
class LoanAccountDAOImplTest {
	List<LoanAccount> listExpected;

	/** Constructor for LoanAccountDAOImplTest */

	public LoanAccountDAOImplTest() {

		listExpected = new ArrayList<>();
		LoanAccount loanAccount1 = new LoanAccount(11141, "Loan Account Holder 1", 500, 10000, 3);
		LoanAccount loanAccount2 = new LoanAccount(11142, "Loan Account Holder 2", 5000, 210000, 5);
		LoanAccount loanAccount3 = new LoanAccount(11143, "Loan Account Holder 3", 100, 20000, 30);
		LoanAccount loanAccount4 = new LoanAccount(11144, "Loan Account Holder 4", 500, 10000, 3);
		listExpected.add(loanAccount1);
		listExpected.add(loanAccount2);
		listExpected.add(loanAccount3);
		listExpected.add(loanAccount4);
	}

	/** Test for Get all Loan account */
	@Test
	void testGetAllLoanAccount() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		List<LoanAccount> actualList = loanAccountDAOImpl.getAllLoanAccount();
		assertEquals(listExpected.size(), actualList.size());
	}

	/** test for get one Loan account by ID */
	@Test
	void testGetLoanAccountByNumber() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		String expected = listExpected.get(0).getAccountHolderName();
		String actual = loanAccountDAOImpl.getLoanAccountByNumber(11141).getAccountHolderName();
		assertEquals(expected, actual);
	}

	/** test for delete one loan account by id */
	@Test
	void testDeleteOneLoanAccountById() {
		LoanAccountDAOImpl loanAccountDAOImpl = new LoanAccountDAOImpl();
		assertNotNull(loanAccountDAOImpl.getLoanAccountByNumber(11131));
		assertTrue(loanAccountDAOImpl.deleteOneLoanAccountById(11131));
	}

}
