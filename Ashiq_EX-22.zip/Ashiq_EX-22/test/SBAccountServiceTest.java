/**
 * Name: SBAccountServiceTest
 * Descriptions: SBAccountServiceTest class is for testing SBAccountService class. 
 * Date: 06/10/2020
 */

package com.ust.banking.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.Entity.FDAccount;
import com.ust.banking.Entity.SBAccount;

import com.ust.banking.service.SBAccountService;

/**
 * This class contains testing methods get all SB account sorted by name and get
 * all SB account sorted by Balance.
 * 
 */
class SBAccountServiceTest {

	List<SBAccount> list;
	SBAccountService sbAccountService;
	
	/** Constructor for SBAccountServiceTest */
	public SBAccountServiceTest() {
		sbAccountService= new SBAccountService();
		/*
		 * list = new ArrayList<>(); SBAccount sbAccount1 = new SBAccount(11112,
		 * "SBAccountNameD", 1000, 2000); SBAccount sbAccount2 = new SBAccount(11113,
		 * "SBAccountNameA", 1000, 4000); SBAccount sbAccount3 = new SBAccount(11114,
		 * "SBAccountNameB", 1000, 300); SBAccount sbAccount4 = new SBAccount(11115,
		 * "SBAccountNameC", 1000, 100); list.add(sbAccount1); list.add(sbAccount2);
		 * list.add(sbAccount3); list.add(sbAccount4);
		 */
		
		sbAccountService.addSBAccount(new SBAccount(11112, "SBAccountNameD", 1000, 2000));
		sbAccountService.addSBAccount(new SBAccount(11113, "SBAccountNameA", 1000, 4000));
		
	}
	
	/** Method is test for add account success*/
	@Test
	void testAddSBAccountSuccess() {

		assertTrue(sbAccountService.addSBAccount(new SBAccount(11114, "SBAccountNameE", 1000, 2000)));
	}

	/** Method is test for add account failure */
	@Test
	void testAddSBAccountFailure() {

		assertFalse(sbAccountService.addSBAccount(new SBAccount(11112, "SBAccountNameD", 1000, 2000)));
	}

	
	/** Method is test for update account success*/
	@Test
	void testUpdateSBAccountSuccess() {
		
		assertTrue(sbAccountService.updateAccount(new SBAccount(11112, "SBAccountNameG", 1000, 2000)));
	}
	
	/** Method is test for update account success failure*/
	@Test
	void testUpdateSBAccountFailure() {
		assertFalse(sbAccountService.updateAccount(new SBAccount(11116, "SBAccountNameD", 1000, 2000)));
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/** Method is test for get all SB account sorted by name */
	/*
	 * @Test void testGetAllSBAccountSortedByName() {
	 * 
	 * List<String> expectedListOfName= new ArrayList<>(); for (SBAccount fdAccount
	 * : list) { expectedListOfName.add(fdAccount.getAccountHolderName()); }
	 * Collections.sort(expectedListOfName);
	 * 
	 * SBAccountService sbAccountService= new SBAccountService(); List<SBAccount>
	 * actual= sbAccountService.getAllSBAccountSortedByName(); List<String>
	 * actualListOfName= new ArrayList<>(); for (SBAccount sbAccount : actual) {
	 * actualListOfName.add(sbAccount.getAccountHolderName()); }
	 * assertEquals(expectedListOfName, actualListOfName); }
	 *//** Method is test for get all SB account sorted by balance *//*
																		 * @Test void
																		 * testGetAllSBAccountSortedByBalance() {
																		 * 
																		 * List<Float> expectedListOfBalance= new
																		 * ArrayList<>(); for (SBAccount fdAccount :
																		 * list) { expectedListOfBalance.add(fdAccount.
																		 * getSBBalance()); }
																		 * Collections.sort(expectedListOfBalance);
																		 * 
																		 * SBAccountService sbAccountService= new
																		 * SBAccountService(); List<SBAccount> actual=
																		 * sbAccountService.
																		 * getAllSBAccountSortedByBalance(); List<Float>
																		 * actualListOfBalace= new ArrayList<>();
																		 * 
																		 * for (SBAccount fdAccount : actual) {
																		 * actualListOfBalace.add(fdAccount.getSBBalance
																		 * ()); } assertEquals(expectedListOfBalance,
																		 * actualListOfBalace); }
																		 */
}
