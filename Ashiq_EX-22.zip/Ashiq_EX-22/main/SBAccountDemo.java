/**
 * Name: SBAccountDemo
 * Description: This is demo class for SBAccount.
 * Date: 06/10/2020
 */

package com.ust.banking.main;

import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.SBAccountService;
/**
 *This class is for display outputs. 
 */
public class SBAccountDemo {

	/**Main method*/
	public static void main(String[] args) {
		
		SBAccountService sbAccountService= new SBAccountService();
		
		
		  System.out.
		  println("=========One particular SB account by Account number===========");
		  sbAccountService.getSBAccountByNumber(11112);
		  System.out.println("=============Delete status============");
		  System.out.println(sbAccountService.deleteOneAccount(11113));
		 
		System.out.println("========List of all SB Accounts By Name=============");
		sbAccountService.getAllSBAccountSortedByName();
		System.out.println("========List of all SB Accounts By Name=============");
		sbAccountService.getAllSBAccountSortedByBalance();
		/*
		 * System.out.
		 * println("==================Add SB accounts========================");
		 * sbAccountService.addSBAccount(new SBAccount(11112, "SBAccountNameD", 1000,
		 * 2000)); sbAccountService.addSBAccount(new SBAccount(11113, "SBAccountNameA",
		 * 1000,4000));
		 * System.out.println("==================Add FD account========================"
		 * ); sbAccountService.updateAccount(new SBAccount(11113, "SBAccountNameF",
		 * 10000,4000)); sbAccountService.updateAccount(new SBAccount(12113,
		 * "SBAccountName", 10000,4000));
		 */
		System.out.println("========List of all SB Accounts=============");
		sbAccountService.getAllSBAccount();
	}

}
