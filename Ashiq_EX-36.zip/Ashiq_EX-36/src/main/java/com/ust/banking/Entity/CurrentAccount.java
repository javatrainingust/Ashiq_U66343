/**
 *Name:CurrentAccount
 *Description: CurrentAccount class is for customers having current account, and which inherits from Account class. 
 *Date: 30/09/2020
 */

package com.ust.banking.Entity;

/**
 * This class contains variable overdraft limit
 * */
public class CurrentAccount extends Account implements Comparable<CurrentAccount> {

	private float overDraftLimit;
	
	/**Getter method for overdraft limit*/
	public float getOverDraftLimit() {
		return overDraftLimit;
	}
	/**Setter method for overdraft limit*/
	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	/**Argument constructor for Current account*/
	public CurrentAccount(int accountNumber, String accountHolderName,float overDraftLimit) {
		super(accountNumber, accountHolderName);
		this.overDraftLimit = overDraftLimit;
	}
	/**No argument constructor for CurrentAccount class*/
	public CurrentAccount() {
		
	}
	@Override
	public int compareTo(CurrentAccount account) {
		// TODO Auto-generated method stub
		return getAccountHolderName().compareTo(account.getAccountHolderName());
	}
	
	
	}
