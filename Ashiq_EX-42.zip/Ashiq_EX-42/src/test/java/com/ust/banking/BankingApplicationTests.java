/**
 * Name: BankingApplicationTests
 * Description: BankingApplicationTests test class for service.
 * Date: 28/10/2020
 * */

package com.ust.banking;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.banking.DAO.SBAccountDAO;
import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.SBAccountService;

/**
 * Test class for methods in service
 * */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class BankingApplicationTests {

@Mock
private SBAccountDAO sbAccountDAOMock;
@InjectMocks
private SBAccountService sbAccountService;

/**
 * This method will test SB Accounts having a balance above an amount
 * */
@Test
public void getSBAccountsHavingBalanceAboveAnAmount() {
	
	SBAccount sbAccount1= new SBAccount();
	sbAccount1.setSBBalance(10000);
	
	SBAccount sbAccount2= new SBAccount();
	sbAccount2.setSBBalance(20000);
	
	SBAccount sbAccount3= new SBAccount();
	sbAccount3.setSBBalance(30000);
	
	SBAccount sbAccount4= new SBAccount();
	sbAccount4.setSBBalance(40000);
	
	List<SBAccount> sbAccounts= new ArrayList<>();
	sbAccounts.add(sbAccount1);
	sbAccounts.add(sbAccount2);
	sbAccounts.add(sbAccount3);
	sbAccounts.add(sbAccount4);
	
	when(sbAccountDAOMock.getAllSBAccount()).thenReturn(sbAccounts);
	assertEquals(2, sbAccountService.getSBAccountsHavingBalanceAboveAnAmount(20000).size());
}


}
