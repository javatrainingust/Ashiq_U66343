/**
 * Name: LoanAccountMapper
 * Description: This is class implements the RowMaper class
 * Date: 23/10/2020
 */

package com.ust.banking.DAO;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.ust.banking.Entity.LoanAccount;


/**
 * This class implements the RowMaper class. 
 * */
public class LoanAccountMapper implements RowMapper<LoanAccount>{

	/**
	 * This is implementation method for mapRow
	 * */
	@Override
	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		LoanAccount loanAccount= new LoanAccount();
		
		loanAccount.setAccountNumber(rs.getInt("accountNumber"));
		loanAccount.setAccountHolderName(rs.getString("accountHolderName"));
		loanAccount.setEmi(rs.getFloat("emi"));
		loanAccount.setLoanOutStanding(rs.getFloat("loanOutStanding"));
		
		return loanAccount;
	}

}
