/**
 * Name: BankingApplication
 * Descriptions: BankingApplication class is main class
 * Date: 15/10/2020
 */
package com.ust.banking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * This class contains the main method
 * */
@SpringBootApplication
public class BankingApplication {
	
	/**
	 * This is main method , which will start the execution. 
	 * */
	public static void main(String[] args) {
		SpringApplication.run(BankingApplication.class, args);
	}

}
