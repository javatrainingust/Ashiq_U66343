/**
 * Name:SBAccountService
 * Descriptions: SBAccountService is for writing business logics for SB Account
 * Date: 06/10/2020
 */

package com.ust.banking.service;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.banking.DAO.SBAccountDAO;
import com.ust.banking.DAO.SBAccountDAOImpl;

import com.ust.banking.Entity.SBAccount;


/**
 * This class contains methods get all SB account, get one SB account by account
 * number SB outstanding, delete one SB account, get all SB account sorted by
 * name, get all SB account sorted by balance.
 * 
 */
@Service
public class SBAccountService {
	@Autowired
	SBAccountDAO sbAccountDAO;

	/** Constructor for SBAccountService */
	public SBAccountService() {
		
	}
	
	public List<SBAccount> getSBAccountsHavingBalanceAboveAnAmount(float amount){
		
		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		List<SBAccount> filteredList= new ArrayList<>();
		for (SBAccount sbAccount : accounts) {
			if(sbAccount.getSBBalance()>amount) {
				filteredList.add(sbAccount);
			}
		}
		return filteredList;
	}

	/** Method is for get all SB accounts */
	public List<SBAccount> getAllSBAccount() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		
		return accounts;
	}

	/** Method is for get all SB accounts sorted by name*/
	public List<SBAccount> getAllSBAccountSortedByName() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		Collections.sort(accounts);
		return accounts;
	}
	
	/** Method is for get all SB accounts sorted by Balance*/
	public List<SBAccount> getAllSBAccountSortedByBalance() {

		List<SBAccount> accounts = sbAccountDAO.getAllSBAccount();
		Collections.sort(accounts, new SBSortedBalance());
		return accounts;
	}
	
	/** Method is for get one SB account by account number */
	public SBAccount getSBAccountByNumber(int accountNumber) {

		SBAccount account = sbAccountDAO.getSBAAccountByNumber(accountNumber);
		
		return account;
	}

	/** Method is for delete one SB account */
	public boolean deleteOneAccount(int accountNumber) {

		return sbAccountDAO.deleteOneSBAccountById(accountNumber);
	}

	
	/**Method to add one SB account*/
	public boolean addSBAccount(SBAccount sbAccount) {
		if (sbAccountDAO.addSBAccount(sbAccount)) {
			System.out.println("Account added suceessfully- Account number : "+sbAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one SB account*/
	public boolean updateAccount(SBAccount sbAccount) {
		if (sbAccountDAO.updateSBAccount(sbAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
	
}
