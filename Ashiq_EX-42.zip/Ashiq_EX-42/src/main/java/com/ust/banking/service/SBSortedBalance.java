/**
 * Name: SBSortedBalance
 * Descriptions: SBSortedBalance class is for sorting SB account in terms of balance. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Comparator;

import com.ust.banking.Entity.SBAccount;

/** This class implements the compare method of Comparator interface */
public class SBSortedBalance implements Comparator<SBAccount> {

	/** Implementation for compare method */
	@Override
	public int compare(SBAccount account1, SBAccount account2) {
		// TODO Auto-generated method stub
		return (int) (account1.getSBBalance() - account2.getSBBalance());
	}

}
