package com.ust.banking.Entity;

public class CurrentAccount extends Account{

	private float overDraftLimit=50000;
	
	public float getOverDraftLimit() {
		return overDraftLimit;
	}

	public float withdrawMoney(float amount) {
		
		 this.overDraftLimit=this.overDraftLimit-amount;
		 
		 return overDraftLimit;
	}
	public float ammountCanWithdraw() {
		return overDraftLimit+getBalance();
	}
	}
