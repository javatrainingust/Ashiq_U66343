package com.ust.banking.Entity;

public interface Renewable {

	public void autoRenewal(int tenure);
}
