package com.ust.banking.Entity;

public class LoanAccount extends Account{
	
	private float emi;
	private float loanOutStanding;
	private int tenure;
	
	public float calcEmi(int tenure, float loanAmount) {
		this.emi=(float) ((loanAmount/tenure)*1.5);
		return emi;
	} 

}
