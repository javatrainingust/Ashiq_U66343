/**
 * Name: FDAccountService
 * Descriptions: FDAccountService class is the service class contains business logics for FD account. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.ust.banking.DAO.FDAccountDAO;
import com.ust.banking.DAO.FDAccountDAOImpl;
import com.ust.banking.Entity.FDAccount;
/**
 * This class contains methods get all fd account, get one fd account by account number,
 * delete one fd account, get all fd account sorted by name, get all fd account sorted by balance. 
 * 
 */
@Service
public class FDAccountService {
	
	FDAccountDAO fdAccountDAO;
	/**Constructor for FDAccountService*/
	
	public FDAccountService() {
		fdAccountDAO= new FDAccountDAOImpl();
	}
	/**Method is for get all FD accounts*/
	public List<FDAccount> getAllFdAccount() {
		
		List<FDAccount> accounts= fdAccountDAO.getAllFdAccount();
		
		return accounts;
	}
	/**Method is for get one FD account by account number*/
	public FDAccount getFDAAccountByNumber(int accountNumber) {
		
		FDAccount account= fdAccountDAO.getFDAAccountByNumber(accountNumber);
		
		return account;
	}
	/**Method is for delete one FD account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return fdAccountDAO.deleteOneAccount(accountNumber);
	}
	
	
	
	/**Method to add one FD account*/
	public boolean addFDAccount(FDAccount fdAccount) {
		if (fdAccountDAO.addFDAccount(fdAccount)) {
			System.out.println("Account added suceessfully- Account number : "+fdAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one FD account*/
	public boolean updateAccount(FDAccount fdAccount) {
		if (fdAccountDAO.updateFDAccount(fdAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
}
