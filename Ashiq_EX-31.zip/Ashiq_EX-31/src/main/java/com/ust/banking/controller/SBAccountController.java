/**
 * Name: SBAccountController
 * Descriptions: SBAccountController class is controller class. 
 * Date: 15/10/2020
 */


package com.ust.banking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ust.banking.Entity.SBAccount;
import com.ust.banking.service.SBAccountService;

/**
 * This controller class contains a method , it returns all SB accounts. 
 * */
@Controller
public class SBAccountController {
	@Autowired
	SBAccountService sbAccountService;
	/**
	 * This method will returns all SB accounts to jsp page. 
	 * */
	@RequestMapping("/getAllSBAccount")
	public String getAllSBAccount(Model model) {
		
		List<SBAccount> listOfSbAccounts= sbAccountService.getAllSBAccount();
		model.addAttribute("sbAccount", listOfSbAccounts);
		return "showAllSBAccounts";
	}
}
