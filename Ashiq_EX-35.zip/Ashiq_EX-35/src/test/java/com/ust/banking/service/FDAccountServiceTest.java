/**
 * Name: FDAccountServiceTest
 * Descriptions: FDAccountServiceTest class is for testing FDAccountService class. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.ust.banking.Entity.FDAccount;

/**
 * This class contains testing methods get all FD account sorted by name and get
 * all FD account sorted by Balance.
 * 
 */
class FDAccountServiceTest {

	List<FDAccount> list;
	FDAccountService fdAccountService;

	/** Constructor for FDAccountServiceTest */

	public FDAccountServiceTest() {

		fdAccountService = new FDAccountService();

		list = new ArrayList<>();

		FDAccount fdAccount1 = new FDAccount(1111, "FDHolderNameB", 1, false, 500);
		FDAccount fdAccount2 = new FDAccount(2222, "FDHolderNameA", 4, true, 100);
		FDAccount fdAccount3 = new FDAccount(3333, "FDHolderNameC", 5, true, 5000);
		FDAccount fdAccount4 = new FDAccount(4444, "FDHolderNameD", 6, false, 3000);
		list.add(fdAccount1);
		list.add(fdAccount2);
		list.add(fdAccount3);
		list.add(fdAccount4);

	}

	/** Method is test for get all FD account */

	@Test
	public void testGetAllFDAccount() {
		
		List<FDAccount> actual = fdAccountService.getAllFdAccount();
		assertEquals(list, actual);

	}
}
