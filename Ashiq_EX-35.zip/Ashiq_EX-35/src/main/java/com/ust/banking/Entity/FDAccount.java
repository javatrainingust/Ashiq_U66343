/**
 *Name: FDAccount
 *Description: FDAccount class is for customers having FD account, and which inherits from Account class. 
 *Date: 30/09/2020
 */

package com.ust.banking.Entity;

/**
 * This FDAccount class contains variables autoReneval, FDBalance and tenure. 
 */
public class FDAccount  extends Account {

	private int tenure;
	
	
	private boolean autoRenewal;
	private float FDBalance;
	/**
	 * Default constructor for FDAccount
	 */
	public FDAccount() {
		
	}
	
	/**Argument constructor for FDAccount*/
	public FDAccount(int accountNumber, String accountHolderName, int tenure, boolean autoRenewal, float FDBalance) {
		
		super(accountNumber, accountHolderName);
		this.tenure = tenure;
		this.autoRenewal = autoRenewal;
		this.FDBalance=FDBalance;
	}
	/**Accessor method for tenure*/
	public float getFDBalance() {
		return FDBalance;
	}
	
	/**Accessor method for tenure*/
	public int getTenure() {
		return tenure;
	}
	/**Setter method for tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	/**Accessor method for isAutoRenewal*/
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	/**Setter method for isAutoRenewal*/
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	
		
	}
	
	/**toString method override*/
	@Override
	public String toString() {
		return "FDAccount [tenure=" + tenure + ", autoRenewal=" + autoRenewal + "]";
	}
	
}
