/**
 * Name: FDAccountService
 * Descriptions: FDAccountService class is the service class contains business logics for FD account. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;

import com.ust.banking.DAO.FDAccountDAO;
import com.ust.banking.DAO.FDAccountDAOImpl;
import com.ust.banking.Entity.FDAccount;
/**
 * This class contains methods get all fd account, get one fd account by account number,
 * delete one fd account, get all fd account sorted by name, get all fd account sorted by balance. 
 * 
 */
public class FDAccountService {
	
	FDAccountDAO fdAccountDAO;
	/**Constructor for FDAccountService*/
	
	public FDAccountService() {
		fdAccountDAO= new FDAccountDAOImpl();
	}
	/**Method is for get all FD accounts*/
	public List<FDAccount> getAllFdAccount() {
		
		List<FDAccount> accounts= fdAccountDAO.getAllFdAccount();
		for (FDAccount fdAccount : accounts) {
			System.out.println(fdAccount.getAccountNumber());
			System.out.println(fdAccount.getAccountHolderName());
			System.out.println(fdAccount.getBalance());
			System.out.println(fdAccount.getTenure());
		}
		return accounts;
	}
	/**Method is for get one FD account by account number*/
	public FDAccount getFDAAccountByNumber(int accountNumber) {
		
		FDAccount account= fdAccountDAO.getFDAAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		System.out.println(account.getTenure());
		return account;
	}
	/**Method is for delete one FD account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return fdAccountDAO.deleteOneAccount(accountNumber);
	}
	
	/**Method is for get all FD accounts sorted by name*/
	public List<FDAccount> getAllFDAccountSortedByName() {
		
		List<FDAccount> accounts= fdAccountDAO.getAllFdAccount();
		Collections.sort(accounts);
		
		for (FDAccount fdAccount : accounts) {
			System.out.println(fdAccount.getAccountNumber());
			System.out.println(fdAccount.getAccountHolderName());
			System.out.println(fdAccount.getBalance());
			System.out.println(fdAccount.getTenure());
		}
		return accounts;
	}
	/**Method is for get all FD accounts sorted by balance*/
	public List<FDAccount> getAllFDAccountSortedByBalance() {
		List<FDAccount> accounts= fdAccountDAO.getAllFdAccount();
		Collections.sort(accounts, new FDSortedBalance());
		
		for (FDAccount fdAccount : accounts) {
			System.out.println(fdAccount.getAccountNumber());
			System.out.println(fdAccount.getAccountHolderName());
			System.out.println("Balance: "+fdAccount.getFDBalance());
			System.out.println("Tenure: "+fdAccount.getTenure());
		}
		return accounts;
	}
	
	/**Method to add one FD account*/
	public boolean addFDAccount(FDAccount fdAccount) {
		if (fdAccountDAO.addFDAccount(fdAccount)) {
			System.out.println("Account added suceessfully- Account number : "+fdAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one FD account*/
	public boolean updateAccount(FDAccount fdAccount) {
		if (fdAccountDAO.updateFDAccount(fdAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
}
