/**
 * Name: LoanAccountService
 * Descriptions: LoanAccountService contains business logics for loan account.   
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;

import com.ust.banking.DAO.LoanAccountDAO;
import com.ust.banking.DAO.LoanAccountDAOImpl;

import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.SBAccount;
/**
 * This class contains methods get all loan account, get one loan account by account number loan outstanding,
 * delete one loan account, get all loan account sorted by name, get all loan account sorted by balance. 
 * 
 */
public class LoanAccountService {

LoanAccountDAO loanAccountDAO;
	/**Constructor for LoanAccountService*/

	public LoanAccountService() {
		loanAccountDAO= new LoanAccountDAOImpl();
	}
	
	/**Method is for get all loan accounts*/
	public List<LoanAccount> getAllLoanAccount() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		for (LoanAccount loanAccount : accounts) {
			System.out.println(loanAccount.getAccountNumber());
			System.out.println(loanAccount.getAccountHolderName());
			System.out.println(loanAccount.getBalance());
		}
		return accounts;
	}
	/**Method is for get one loan account by account number*/
	public LoanAccount getLoanAccountByNumber(int accountNumber) {
		
		LoanAccount account= loanAccountDAO.getLoanAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		return account;
	}
	
	/**Method is for delete one loan account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return loanAccountDAO.deleteOneLoanAccountById(accountNumber);
	}
	/**Method is for get all loan accounts sorted by name*/
	public List<LoanAccount> getAllLoanAccountSortedByName() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		Collections.sort(accounts);
		for (LoanAccount loanAccount : accounts) {
			System.out.println(loanAccount.getAccountNumber());
			System.out.println(loanAccount.getAccountHolderName());
			System.out.println(loanAccount.getBalance());
		}
		return accounts;
	}
	/**Method is for get all loan accounts sorted by loan outstanding*/
	public List<LoanAccount> getAllLoanAccountSortedByLoanOutStanding() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		Collections.sort(accounts, new LoanAccountSortedAmount());
		for (LoanAccount loanAccount : accounts) {
			System.out.println(loanAccount.getAccountNumber());
			System.out.println(loanAccount.getAccountHolderName());
			System.out.println("Loan outstanding::"+loanAccount.getLoanOutStanding());
		}
		return accounts;
	}
	
	/**Method to add one Loan account*/
	public boolean addLoanAccount(LoanAccount loanAccount) {
		if (loanAccountDAO.addLoanAccount(loanAccount)) {
			System.out.println("Account added suceessfully- Account number : "+loanAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one Loan account*/
	public boolean updateAccount(LoanAccount loanAccount) {
		if (loanAccountDAO.updateLoanAccount(loanAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
	
}
