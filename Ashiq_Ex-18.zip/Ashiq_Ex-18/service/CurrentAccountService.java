/**
 * Name: CurrentAccountService
 * Descriptions: CurrentAccountService class is the service class contains business logics for Current account. 
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;

import com.ust.banking.DAO.CurrentAccountDAO;
import com.ust.banking.DAO.CurrentAccountDAOImpl;
import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.LoanAccount;

/**
 * This class contains methods get all current account, get one current account by account number,
 * delete one current account, get all current account sorted by name, get all current account sorted by Overdraft Limit
 * 
 */
public class CurrentAccountService {

CurrentAccountDAO currentAccountDAO;
	
	public CurrentAccountService() {
		currentAccountDAO= new CurrentAccountDAOImpl();
	}
	
	/**Method is for get all current account*/
	public List<CurrentAccount> getAllCurrentAccount() {
		
		List<CurrentAccount> accounts= currentAccountDAO.getAllCurrentAccount();
		for (CurrentAccount currentAccount : accounts) {
			System.out.println(currentAccount.getAccountNumber());
			System.out.println(currentAccount.getAccountHolderName());
			System.out.println(currentAccount.getBalance());
			System.out.println(currentAccount.getOverDraftLimit());
		}
		return accounts;
	}
	
	/**Method is for get one current account by account number*/
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		
		CurrentAccount account= currentAccountDAO.getCurrentAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		System.out.println(account.getOverDraftLimit());
		return account;
	}
	
	/**Method is for delete one current account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return currentAccountDAO.deleteOneCurrentAccountById(accountNumber);
	}
	
	/**Method is for get all current account sorted by name*/
	public List<CurrentAccount> getAllCurrentAccountSortedByName() {
		
		List<CurrentAccount> accounts= currentAccountDAO.getAllCurrentAccount();
		Collections.sort(accounts);
		for (CurrentAccount currentAccount : accounts) {
			System.out.println(currentAccount.getAccountNumber());
			System.out.println("Name: "+currentAccount.getAccountHolderName());
			System.out.println(currentAccount.getBalance());
			System.out.println("OverDraftLimit: "+currentAccount.getOverDraftLimit());
		}
		return accounts;
	}
	/**Method is for get all current account sorted by Overdraft Limit*/
	public List<CurrentAccount> getAllCurrentAccountSortedByOverdraftLimit() {
		
		List<CurrentAccount> accounts= currentAccountDAO.getAllCurrentAccount();
		Collections.sort(accounts ,new CurrentAccountSortedOverdraftLimit());
		for (CurrentAccount currentAccount : accounts) {
			System.out.println(currentAccount.getAccountNumber());
			System.out.println("Name: "+currentAccount.getAccountHolderName());
			System.out.println(currentAccount.getBalance());
			System.out.println("OverDraftLimit: "+currentAccount.getOverDraftLimit());
		}
		return accounts;
	}
	
	/**Method to add one Current account*/
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		if (currentAccountDAO.addCurrentAccount(currentAccount)) {
			System.out.println("Account added suceessfully- Account number : "+currentAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one Current account*/
	public boolean updateAccount(CurrentAccount currentAccount) {
		if (currentAccountDAO.updateCurrentAccount(currentAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
}
