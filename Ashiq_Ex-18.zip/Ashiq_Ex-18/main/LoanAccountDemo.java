/**
 * Name: LoanAccountDemo
 * Description: This is demo class for LoanAccount.
 * Date: 06/10/2020
 */

package com.ust.banking.main;

import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.service.LoanAccountService;
/**
 * This method is for display outputs. 
 */
public class LoanAccountDemo {

	/**Main method*/
	public static void main(String[] args) {
		
		LoanAccountService loanAccountService= new LoanAccountService();
		System.out.println("========List of all Loan Accounts=============");
		loanAccountService.getAllLoanAccount();
		/*
		 * System.out.
		 * println("=========One particular Current account by Account number==========="
		 * ); loanAccountService.getLoanAccountByNumber(11141);
		 * System.out.println("=============Delete status============");
		 * System.out.println(loanAccountService.deleteOneAccount(11142));
		 */
		System.out.println("========List of all Loan Accounts Sorted By Name=============");
		loanAccountService.getAllLoanAccountSortedByName();
		System.out.println("========List of all Loan Accounts Sorted By loan outstanding=============");
		loanAccountService.getAllLoanAccountSortedByLoanOutStanding();
		System.out.println("===============Loan Account Addition=========================");
		loanAccountService.addLoanAccount(new LoanAccount(11141, "Loan Account Holder A",500, 10000, 3));
		loanAccountService.addLoanAccount(new LoanAccount(11142, "Loan Account Holder B",500, 50000, 3));
		System.out.println("===============Loan Account update=========================");
		loanAccountService.updateAccount(new LoanAccount(11142, "Loan Account Holder F",500, 50000, 3));
		System.out.println("========List of all Loan Accounts=============");
		loanAccountService.getAllLoanAccount();
	}

}
