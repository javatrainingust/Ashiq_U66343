/**
 * Name: FDAccountMain
 * Description: This is demo class for FDAccount.
 * Date: 06/10/2020
 */

package com.ust.banking.main;

import com.ust.banking.Entity.FDAccount;
import com.ust.banking.service.FDAccountService;
/**
 * This class is for display the outputs.
 */
public class FDAccountMain {

	/**Main method*/
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FDAccountService fdAccountService= new FDAccountService();
		/*
		 * System.out.println("========List of all FD Accounts=============");
		 * fdAccountService.getAllFdAccount(); System.out.
		 * println("========List of all FD Accounts Sorted By Name=============");
		 */
		/*
		 * System.out.
		 * println("=========One particular account by Account number===========");
		 * fdAccountService.getFDAAccountByNumber(1111);
		 * System.out.println("=============Delete status============");
		 * System.out.println(fdAccountService.deleteOneAccount(2222));
		 */
		fdAccountService.getAllFDAccountSortedByName();
		System.out.println("========List of all FD Accounts Sorted By Balance=============");
		fdAccountService.getAllFDAccountSortedByBalance();
		System.out.println("=================Adding new FD Account===============");
		fdAccountService.addFDAccount(new FDAccount(1111, "FDHolderNameB", 1, false, 500));
		fdAccountService.addFDAccount(new FDAccount(2222, "FDHolderNameA", 4, true, 100));
		fdAccountService.addFDAccount(new FDAccount(2222, "FDHolderNameA", 4, true, 100));
		
		System.out.println("=============Updating Account=================");
		fdAccountService.updateAccount(new FDAccount(1111, "FDHolderNameF", 1, false, 50000));
		fdAccountService.updateAccount(new FDAccount(1211, "FDHolderNameF", 1, false, 50000));
		System.out.println("========List of all FD Accounts=============");
		fdAccountService.getAllFdAccount();
	}

}
