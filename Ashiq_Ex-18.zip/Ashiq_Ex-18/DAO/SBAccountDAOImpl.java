
/**
 * Name: SBAccountDAOImpl
 * Description: This is implementation for SBAccountDAO interface.
 * Date: 07/10/2020
 */
package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import com.ust.banking.Entity.SBAccount;

/**
 * SBAccountDAOImpl is the implementation class for SBAccountDAO
 */
public class SBAccountDAOImpl implements SBAccountDAO {

	List<SBAccount> sbAccountList;
	Set<SBAccount> sbAccountSet;

	public SBAccountDAOImpl() {
		sbAccountList = new ArrayList<>();
		sbAccountSet = new HashSet<>();
		/*
		 * SBAccount sbAccount1= new SBAccount(11112, "SBAccountNameD", 1000, 2000);
		 * SBAccount sbAccount2= new SBAccount(11113, "SBAccountNameA", 1000,4000);
		 * SBAccount sbAccount3= new SBAccount(11114, "SBAccountNameB", 1000,300);
		 * SBAccount sbAccount4= new SBAccount(11115, "SBAccountNameC", 1000,100);
		 * sbAccountList.add(sbAccount1); sbAccountList.add(sbAccount2);
		 * sbAccountList.add(sbAccount3); sbAccountList.add(sbAccount4);
		 */
	}

	/**
	 * Method is for delete one SB account
	 */
	@Override
	public List<SBAccount> getAllSBAccount() {
		// TODO Auto-generated method stub
		return sbAccountList;
	}

	/** Method is for get one SB account by account number */
	@Override
	public SBAccount getSBAAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		SBAccount sbAccount = null;
		Iterator<SBAccount> iterator = sbAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sbAccount2 = iterator.next();
			if (sbAccount2.getAccountNumber() == accountNumber) {
				sbAccount = sbAccount2;
			}

		}
		return sbAccount;
	}

	/** Method is for delete one SB account */
	@Override
	public boolean deleteOneSBAccountById(int accountNumber) {
		// TODO Auto-generated method stub
		for (SBAccount sbAccount : sbAccountList) {
			if (sbAccount.getAccountNumber() == accountNumber) {
				sbAccountList.remove(sbAccount);
				return true;
			}
		}
		return false;
	}

	/** Method is for add one SB account */
	@Override
	public boolean addSBAccount(SBAccount sbAccount) {
		boolean isAdded = sbAccountSet.add(sbAccount);
		if (isAdded) {
			sbAccountList.add(sbAccount);
			return true;
		}

		return false;
	}

	/** Method is for update one SB account */
	@Override
	public boolean updateSBAccount(SBAccount sbAccount) {

		for (SBAccount oneSbAccount : sbAccountList) {

			if (oneSbAccount.getAccountNumber() == sbAccount.getAccountNumber()) {
				oneSbAccount.setAccountHolderName(sbAccount.getAccountHolderName());
				
				oneSbAccount.setMinimumBalance(sbAccount.getMinimumBalance());
				return true;
			}
		}
		return false;
	}

}
