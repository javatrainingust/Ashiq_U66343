/**
 * Name: CurrentAccountDAOImpl
 * Description: This is implementation for CurrentAccountDAO interface.
 * Date: 07/10/2020
 */

package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.LoanAccount;

/**
 * CurrentAccountDAOImpl contains implementation methods for CurrentAccountDAO interface.
 * 
 */
public class CurrentAccountDAOImpl implements CurrentAccountDAO{
	
	List<CurrentAccount> currentAccountList;
	Set<CurrentAccount> currentAccountSet;
	
	/** Constructor for CurrentAccountDAOImpl class*/	
	public CurrentAccountDAOImpl() {
		currentAccountList= new ArrayList<>();
		currentAccountSet = new HashSet<>();
		/*
		 * CurrentAccount currentAccount1 = new CurrentAccount(11131,
		 * "CurrentAccountHolder A", 50000); CurrentAccount currentAccount2 = new
		 * CurrentAccount(11132, "CurrentAccountHolder D", 5000); CurrentAccount
		 * currentAccount3 = new CurrentAccount(11133, "CurrentAccountHolder B",
		 * 110000); CurrentAccount currentAccount4 = new CurrentAccount(11134,
		 * "CurrentAccountHolder C", 1000); currentAccountList.add(currentAccount1);
		 * currentAccountList.add(currentAccount2);
		 * currentAccountList.add(currentAccount3);
		 * currentAccountList.add(currentAccount4);
		 */
		
	}
	/**Method is for get all current account*/
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}
	
	/**Method is for get one current account by account number*/
	@Override
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			return currentAccount;
		}
		return null;
	}
	/**Method is for delete one current account*/
	@Override
	public boolean deleteOneCurrentAccountById(int accountNumber) {
	
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			currentAccountList.remove(currentAccount);
			return true;
		}
		return false;
	}
	/** Method is for add one current account */
	@Override
	public boolean addCurrentAccount(CurrentAccount currentAccount) {
		boolean isAdded = currentAccountSet.add(currentAccount);
		if (isAdded) {
			currentAccountList.add(currentAccount);
			return true;
		}

		return false;
	}

	/** Method is for update one Current account */
	@Override
	public boolean updateCurrentAccount(CurrentAccount currentAccount) {

		for (CurrentAccount oneCurrentAccount : currentAccountList) {

			if (oneCurrentAccount.getAccountNumber() == currentAccount.getAccountNumber()) {
				oneCurrentAccount.setAccountHolderName(currentAccount.getAccountHolderName());
				oneCurrentAccount.setOverDraftLimit(currentAccount.getOverDraftLimit());
				return true;
			}
		}
		return false;
	}

}
