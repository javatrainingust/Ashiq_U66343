/**
 * Name:Performer
 * Description: Performer interface  contains a perform method. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;
		
/**
 * This interface contains a method perform. 
 * */
public interface Performer {

	/**
	 * perform method is implementing in Singer class. 
	 * */
	public void perform();
}
