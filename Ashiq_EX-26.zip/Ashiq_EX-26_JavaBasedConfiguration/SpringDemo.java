/**
 * Name: SpringDemo
 * Description: SpringDemo class Demo class for organiser. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * This is demo class for organiser, contains main method. 
 * */
public class SpringDemo {

	/**
	 * This is main method which calls the say greetings method of organiser. 
	 * */

	
	public static void main(String[] args) {
		
		/*
		 * ClassPathXmlApplicationContext context= new
		 * ClassPathXmlApplicationContext("applicationContext.xml");
		 *
		 */
		AnnotationConfigApplicationContext context= new AnnotationConfigApplicationContext(SpringConfig.class);
		
		  
		  Organiser organiser= context.getBean("organiser", Organiser.class);
		  organiser.sayGreetings();
		 
		
		

	}

}
