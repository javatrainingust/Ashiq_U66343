/**
 * Name:SpringConfig
 * Description: SpringConfig class is for configuration 
 * Date:13/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * This class is for configuration. 
 * */
@Configuration
public class SpringConfig {
	
	/**
	 * Bean configuration for organiser
	 * */
	@Bean(name= "organiser")
	public Organiser getOrganiser() {
		
		Organiser organiser= new Organiser();
		return organiser;
	}
	
	/**
	 * Bean configuration for instrumentalist.
	 * */
	@Bean(name="instrumentalist")
	public Instrumentalist getInstrumentalist() {
		Instrumentalist instrumentalist= new Instrumentalist();
		instrumentalist.setSaxophone(getSaxophone());
		return instrumentalist;
	}
	
	/**
	 * Bean configuration for Saxophone. 
	 * */
	@Bean
	public Saxophone getSaxophone() {
		Saxophone saxophone= new Saxophone();
		return saxophone;
	}
}
