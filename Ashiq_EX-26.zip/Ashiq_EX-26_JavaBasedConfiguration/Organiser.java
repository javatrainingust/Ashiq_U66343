/**
 * Name:Organiser
 * Description: Organiser class contains a method called sayGreetings. 
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.stereotype.Component;

/**
 * This class contains a method called sayGreetings
 * */

public class Organiser {

	/**
	 * This method will print "Welcome to the talent competion"
	 * */
	public String sayGreetings() {
		System.out.println("Welcome to the talent competion");
		return "Welcome to the talent competion";
	}
}
