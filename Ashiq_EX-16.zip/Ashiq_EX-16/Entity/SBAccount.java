package com.ust.banking.Entity;


/**SBAccount class is for customers having SB account, and which inherits from Account
 *Date: 30/09/2020
 */
public class SBAccount extends Account {
	
	private float minimumBalance;
	
	public float getMinimumBalance() {
		return minimumBalance;
	}

	public SBAccount(int accountNumber, String accountHolderName, float minimumBalance) {
		super(accountNumber, accountHolderName);
		this.minimumBalance = minimumBalance;
	}

	public void setMinimumBalance(float minimumBalance) {
		this.minimumBalance = minimumBalance;
	}

	/*No argument constructor for account class*/
	public SBAccount() {
		
	}
	
	
}
