package com.ust.banking.Entity;

/**CurrentAccount class is for customers having current account, and which inherits from Account
 *Date: 30/09/2020
 */
public class CurrentAccount extends Account{

	private float overDraftLimit;
	
	public float getOverDraftLimit() {
		return overDraftLimit;
	}
	public void setOverDraftLimit(float overDraftLimit) {
		this.overDraftLimit = overDraftLimit;
	}
	public CurrentAccount(int accountNumber, String accountHolderName,float overDraftLimit) {
		super(accountNumber, accountHolderName);
		this.overDraftLimit = overDraftLimit;
	}
	/*No argument constructor for CurrentAccount class*/
	public CurrentAccount() {
		
	}
	
	}
