package com.ust.banking.service;

import java.util.List;

import com.ust.banking.DAO.LoanAccountDAO;
import com.ust.banking.DAO.LoanAccountDAOImpl;

import com.ust.banking.Entity.LoanAccount;
/**
 * This is service class for Loan Account.
 * Date: 06/10/2020
 */
public class LoanAccountService {

LoanAccountDAO loanAccountDAO;
	
	public LoanAccountService() {
		loanAccountDAO= new LoanAccountDAOImpl();
	}
	/*Method is for get all loan accounts*/
	public List<LoanAccount> getAllLoanAccount() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		for (LoanAccount loanAccount : accounts) {
			System.out.println(loanAccount.getAccountNumber());
			System.out.println(loanAccount.getAccountHolderName());
			System.out.println(loanAccount.getBalance());
		}
		return accounts;
	}
	/*Method is for get one loan account by account number*/
	public LoanAccount getLoanAccountByNumber(int accountNumber) {
		
		LoanAccount account= loanAccountDAO.getLoanAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		return account;
	}
	/*Method is for delete one loan account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return loanAccountDAO.deleteOneLoanAccountById(accountNumber);
	}
}
