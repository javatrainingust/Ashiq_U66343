package com.ust.banking.service;

import java.util.List;

import com.ust.banking.DAO.CurrentAccountDAO;
import com.ust.banking.DAO.CurrentAccountDAOImpl;
import com.ust.banking.Entity.CurrentAccount;
/**
 * This is service class for CurrentAccount.
 * Date: 06/10/2020
 */
public class CurrentAccountService {

CurrentAccountDAO currentAccountDAO;
	
	public CurrentAccountService() {
		currentAccountDAO= new CurrentAccountDAOImpl();
	}
	
	/*Method is for get all current account*/
	public List<CurrentAccount> getAllCurrentAccount() {
		
		List<CurrentAccount> accounts= currentAccountDAO.getAllCurrentAccount();
		for (CurrentAccount currentAccount : accounts) {
			System.out.println(currentAccount.getAccountNumber());
			System.out.println(currentAccount.getAccountHolderName());
			System.out.println(currentAccount.getBalance());
			System.out.println(currentAccount.getOverDraftLimit());
		}
		return accounts;
	}
	/*Method is for get one current account by account number*/
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		
		CurrentAccount account= currentAccountDAO.getCurrentAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		System.out.println(account.getOverDraftLimit());
		return account;
	}
	/*Method is for delete one current account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return currentAccountDAO.deleteOneCurrentAccountById(accountNumber);
	}
}
