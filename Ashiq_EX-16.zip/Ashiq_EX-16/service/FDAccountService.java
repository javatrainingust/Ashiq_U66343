package com.ust.banking.service;

import java.util.List;

import com.ust.banking.DAO.FDAccountDAO;
import com.ust.banking.DAO.FDAccountDAOImpl;
import com.ust.banking.Entity.FDAccount;
/**
 * This is service class for FD Account.
 * Date: 06/10/2020
 */
public class FDAccountService {
	
	FDAccountDAO fdAccountDAO;
	
	public FDAccountService() {
		fdAccountDAO= new FDAccountDAOImpl();
	}
	/*Method is for get all FD accounts*/
	public List<FDAccount> getAllFdAccount() {
		
		List<FDAccount> accounts= fdAccountDAO.getAllFdAccount();
		for (FDAccount fdAccount : accounts) {
			System.out.println(fdAccount.getAccountNumber());
			System.out.println(fdAccount.getAccountHolderName());
			System.out.println(fdAccount.getBalance());
			System.out.println(fdAccount.getTenure());
		}
		return accounts;
	}
	/*Method is for get one FD account by account number*/
	public FDAccount getFDAAccountByNumber(int accountNumber) {
		
		FDAccount account= fdAccountDAO.getFDAAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		System.out.println(account.getTenure());
		return account;
	}
	/*Method is for delete one FD account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return fdAccountDAO.deleteOneAccount(accountNumber);
	}

}
