package com.ust.banking.service;

import java.util.List;

import com.ust.banking.DAO.SBAccountDAO;
import com.ust.banking.DAO.SBAccountDAOImpl;
import com.ust.banking.Entity.SBAccount;
/**
 * This is service class for SB Account.
 * Date: 06/10/2020
 */
public class SBAccountService {
SBAccountDAO sbAccountDAO;
	
	public SBAccountService() {
		sbAccountDAO= new SBAccountDAOImpl();
	}
	/*Method is for get all SB accounts*/
	public List<SBAccount> getAllSBAccount() {
		
		List<SBAccount> accounts= sbAccountDAO.getAllSBAccount();
		for (SBAccount sbAccount : accounts) {
			System.out.println(sbAccount.getAccountNumber());
			System.out.println(sbAccount.getAccountHolderName());
			System.out.println(sbAccount.getBalance());
			System.out.println(sbAccount.getMinimumBalance());
		}
		return accounts;
	}
	/*Method is for get one SB account by account number*/
	public SBAccount getSBAccountByNumber(int accountNumber) {
		
		SBAccount account= sbAccountDAO.getSBAAccountByNumber(accountNumber);
		System.out.println(account.getAccountNumber());
		System.out.println(account.getAccountHolderName());
		System.out.println(account.getBalance());
		System.out.println(account.getMinimumBalance());
		return account;
	}
	/*Method is for delete one SB account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return sbAccountDAO.deleteOneSBAccountById(accountNumber);
	}
}
