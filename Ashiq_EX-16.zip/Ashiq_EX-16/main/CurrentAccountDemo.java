package com.ust.banking.main;

import com.ust.banking.service.CurrentAccountService;
/**
 * This is demo class for CurrentAccount.
 * Date: 06/10/2020
 */
public class CurrentAccountDemo {

	public static void main(String[] args) {
		
		CurrentAccountService currentAccountService= new CurrentAccountService();
		System.out.println("========List of all Current Accounts=============");
		currentAccountService.getAllCurrentAccount();
		System.out.println("=========One particular Current account by Account number===========");
		currentAccountService.getCurrentAccountByNumber(11131);
		System.out.println("=============Delete status============");
		System.out.println(currentAccountService.deleteOneAccount(11132));

	}

}
