package com.ust.banking.main;

import com.ust.banking.service.FDAccountService;
/**
 * This is demo class for FDAccount.
 * Date: 06/10/2020
 */
public class FDAccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FDAccountService fdAccountService= new FDAccountService();
		System.out.println("========List of all FD Accounts=============");
		fdAccountService.getAllFdAccount();
		System.out.println("=========One particular account by Account number===========");
		fdAccountService.getFDAAccountByNumber(1111);
		System.out.println("=============Delete status============");
		System.out.println(fdAccountService.deleteOneAccount(2222));
		
	}

}
