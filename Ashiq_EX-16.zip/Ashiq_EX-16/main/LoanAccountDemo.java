package com.ust.banking.main;

import com.ust.banking.service.LoanAccountService;
/**
 * This is demo class for LoanAccount.
 * Date: 06/10/2020
 */
public class LoanAccountDemo {

	public static void main(String[] args) {
		
		LoanAccountService loanAccountService= new LoanAccountService();
		System.out.println("========List of all Loan Accounts=============");
		loanAccountService.getAllLoanAccount();
		System.out.println("=========One particular Current account by Account number===========");
		loanAccountService.getLoanAccountByNumber(11141);
		System.out.println("=============Delete status============");
		System.out.println(loanAccountService.deleteOneAccount(11142));

	}

}
