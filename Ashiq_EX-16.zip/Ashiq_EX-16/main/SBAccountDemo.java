package com.ust.banking.main;

import com.ust.banking.service.SBAccountService;
/**
 * This is demo class for LoanAccount.
 * Date: 06/10/2020
 */
public class SBAccountDemo {

	public static void main(String[] args) {
		
		SBAccountService sbAccountService= new SBAccountService();
		System.out.println("========List of all SB Accounts=============");
		sbAccountService.getAllSBAccount();
		System.out.println("=========One particular SB account by Account number===========");
		sbAccountService.getSBAccountByNumber(11112);
		System.out.println("=============Delete status============");
		System.out.println(sbAccountService.deleteOneAccount(11113));

	}

}
