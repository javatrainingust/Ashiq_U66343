package com.ust.banking.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.DAO.CurrentAccountDAOImpl;
import com.ust.banking.Entity.CurrentAccount;

/**
 * This is JUnit Test for CurrentAccountDAOImp
 * Date: 06/10/2020
 */

class CurrentAccountDAOImplTest {
	List<CurrentAccount> listExpected;
	
	public CurrentAccountDAOImplTest() {
		listExpected= new ArrayList<>();
		
		CurrentAccount currentAccount1 = new CurrentAccount(11131, "CurrentAccountHolder1", 50000);
		CurrentAccount currentAccount2 = new CurrentAccount(11132, "CurrentAccountHolder2", 50000);
		CurrentAccount currentAccount3 = new CurrentAccount(11133, "CurrentAccountHolder3", 50000);
		CurrentAccount currentAccount4 = new CurrentAccount(11134, "CurrentAccountHolder4", 50000);
		listExpected.add(currentAccount1);
		listExpected.add(currentAccount2);
		listExpected.add(currentAccount3);
		listExpected.add(currentAccount4);
	}
	/*Test for Get all Current account*/
	@Test
	void testGetAllCurrentAccount() {
		CurrentAccountDAOImpl currentAccountDAOImpl= new CurrentAccountDAOImpl();
		List<CurrentAccount> actualList= currentAccountDAOImpl.getAllCurrentAccount();
		assertEquals(listExpected.size(), actualList.size());
	}
	/*test for get one Current account by ID*/
	@Test
	void testGetCurrentAccountByNumber() {
		CurrentAccountDAOImpl currentAccountDAOImpl= new CurrentAccountDAOImpl();
		  String expected= listExpected.get(0).getAccountHolderName();
		  String actual= currentAccountDAOImpl.getCurrentAccountByNumber(11131).getAccountHolderName();
		  assertEquals(expected, actual);
	}
	/*test for delete one Current account by id*/
	@Test
	void testDeleteOneCurrentAccountById() {
		CurrentAccountDAOImpl currentAccountDAOImpl= new CurrentAccountDAOImpl();
		assertNotNull(currentAccountDAOImpl.getCurrentAccountByNumber(11131));
		assertTrue(currentAccountDAOImpl.deleteOneCurrentAccountById(11131));

	}

}
