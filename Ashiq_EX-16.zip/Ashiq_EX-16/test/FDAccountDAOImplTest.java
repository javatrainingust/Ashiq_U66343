package com.ust.banking.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.DAO.FDAccountDAOImpl;

import com.ust.banking.Entity.FDAccount;
/**
 * This is JUnit Test for FD AccountDAOImp
 * Date: 06/10/2020
 */
class FDAccountDAOImplTest {
	
	
	List<FDAccount> listExpected;
	public FDAccountDAOImplTest() {
		
		
		listExpected= new ArrayList<>();
	  	FDAccount fdAccount1=new FDAccount(1111, "FDHolderName1", 1, false);
		FDAccount fdAccount2=new FDAccount(2222, "FDHolderName2", 4, true);
		FDAccount fdAccount3=new FDAccount(3333, "FDHolderName3", 5, true);
		FDAccount fdAccount4=new FDAccount(4444, "FDHolderName4", 6, false);
		listExpected.add(fdAccount1);
		listExpected.add(fdAccount2);
		listExpected.add(fdAccount3);
		listExpected.add(fdAccount4);
		
	}
	

	/*Test for Get all FD account*/
	
	@Test
	void testGetAllFdAccount() {
		FDAccountDAOImpl fdAccountDAOImpl=new FDAccountDAOImpl();
		List<FDAccount> actualList= fdAccountDAOImpl.getAllFdAccount();
		assertEquals(listExpected.size(), actualList.size());

	}

	/*test for get one FD account by ID*/
	  @Test 
	  void testGetFDAAccountByNumber() {
		  FDAccountDAOImpl fdAccountDAOImpl=new FDAccountDAOImpl();
		  String expected= listExpected.get(0).getAccountHolderName();
		  String actual= fdAccountDAOImpl.getFDAAccountByNumber(1111).getAccountHolderName();
		  assertEquals(expected, actual);
		  
		  
	  }
	  /*test for delete one FD account by id*/
	  @Test 
	  void testDeleteOneAccount() { 
		 FDAccountDAOImpl fdAccountDAOImpl= new FDAccountDAOImpl();
		 
		assertNotNull(fdAccountDAOImpl.getFDAAccountByNumber(1111));
		assertTrue(fdAccountDAOImpl.deleteOneAccount(1111));
		assertNull(fdAccountDAOImpl.getFDAAccountByNumber(1111));
		
		  
	  }
	 
}
