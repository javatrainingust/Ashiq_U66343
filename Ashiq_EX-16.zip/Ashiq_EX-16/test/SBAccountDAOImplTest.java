package com.ust.banking.test;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ust.banking.DAO.SBAccountDAOImpl;

import com.ust.banking.Entity.SBAccount;
/**
 * This is JUnit Test for SB AccountDAOImp
 * Date: 06/10/2020
 */
class SBAccountDAOImplTest {

	List<SBAccount> listExpected;
	public SBAccountDAOImplTest() {
		
		
		listExpected= new ArrayList<>();
		SBAccount sbAccount1= new SBAccount(11112, "SBAccountName1", 1000);
		SBAccount sbAccount2= new SBAccount(11113, "SBAccountName2", 1000);
		SBAccount sbAccount3= new SBAccount(11114, "SBAccountName3", 1000);
		SBAccount sbAccount4= new SBAccount(11115, "SBAccountName4", 1000);
		listExpected.add(sbAccount1);
		listExpected.add(sbAccount2);
		listExpected.add(sbAccount3);
		listExpected.add(sbAccount4);
		
	}
	/*Test for Get all SB account*/
	@Test
	void testGetAllSBAccount() {
		
		SBAccountDAOImpl sbAccountDAOImpl=new SBAccountDAOImpl();
		List<SBAccount> actualList= sbAccountDAOImpl.getAllSBAccount();
		assertEquals(listExpected.size(), actualList.size());
	}
	/*test for get one SB account by ID*/
	@Test
	void testGetSBAAccountByNumber() {
		
		SBAccountDAOImpl sbAccountDAOImpl=new SBAccountDAOImpl();
		  String expected= listExpected.get(0).getAccountHolderName();
		  String actual= sbAccountDAOImpl.getSBAAccountByNumber(11112).getAccountHolderName();
		  assertEquals(expected, actual);
	}
	/*test for delete one SB account by id*/
	@Test
	void testDeleteOneSBAccountById() {
		SBAccountDAOImpl sbAccountDAOImpl=new SBAccountDAOImpl();
		assertNotNull(sbAccountDAOImpl.getSBAAccountByNumber(11112));
		assertTrue(sbAccountDAOImpl.deleteOneSBAccountById(11112));
		assertNull(sbAccountDAOImpl.getSBAAccountByNumber(11112));
	}

}
