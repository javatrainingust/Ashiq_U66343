package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.SBAccount;

/**
 * This is interface for Loan Account.
 * Date: 06/10/2020
 */

public interface SBAccountDAO {
	/*Method is for get all SB accounts*/
	public List<SBAccount> getAllSBAccount();
	/*Method is for get one SB account by account number*/
	public SBAccount getSBAAccountByNumber(int accountNumber);
	/*Method is for delete one SB account*/
	public boolean deleteOneSBAccountById(int accountNumber);
}
