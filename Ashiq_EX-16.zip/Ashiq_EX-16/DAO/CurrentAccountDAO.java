package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.CurrentAccount;

/**
 * This is interface for Current Account.
 * Date: 06/10/2020
 */

public interface CurrentAccountDAO {
	/*Method is for get all current account*/
	public List<CurrentAccount> getAllCurrentAccount();
	/*Method is for get one current account by account number*/
	public CurrentAccount getCurrentAccountByNumber(int accountNumber);
	/*Method is for delete one current account*/
	public boolean deleteOneCurrentAccountById(int accountNumber);
}
