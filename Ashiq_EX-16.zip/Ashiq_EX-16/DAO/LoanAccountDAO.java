package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.LoanAccount;

/**
 * This is interface for Loan Account.
 * Date: 06/10/2020
 */
public interface LoanAccountDAO {
	/*Method is for get all loan accounts*/
	public List<LoanAccount> getAllLoanAccount();
	/*Method is for get one loan account by account number*/
	public LoanAccount getLoanAccountByNumber(int accountNumber);
	/*Method is for delete one loan account*/
	public boolean deleteOneLoanAccountById(int accountNumber);
}
