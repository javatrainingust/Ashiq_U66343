package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.List;

import com.ust.banking.Entity.CurrentAccount;

/**
 * This is implementation for CurrentAccountDAO interface.
 * Date: 06/10/2020
 */
public class CurrentAccountDAOImpl implements CurrentAccountDAO{
	
	List<CurrentAccount> currentAccountList;
	public CurrentAccountDAOImpl() {
		currentAccountList= new ArrayList<>();
		CurrentAccount currentAccount1 = new CurrentAccount(11131, "CurrentAccountHolder1", 50000);
		CurrentAccount currentAccount2 = new CurrentAccount(11132, "CurrentAccountHolder2", 50000);
		CurrentAccount currentAccount3 = new CurrentAccount(11133, "CurrentAccountHolder3", 50000);
		CurrentAccount currentAccount4 = new CurrentAccount(11134, "CurrentAccountHolder4", 50000);
		currentAccountList.add(currentAccount1);
		currentAccountList.add(currentAccount2);
		currentAccountList.add(currentAccount3);
		currentAccountList.add(currentAccount4);
		
	}
	/*Method is for get all current account*/
	@Override
	public List<CurrentAccount> getAllCurrentAccount() {
		// TODO Auto-generated method stub
		return currentAccountList;
	}
	/*Method is for get one current account by account number*/
	@Override
	public CurrentAccount getCurrentAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			return currentAccount;
		}
		return null;
	}
	/*Method is for delete one current account*/
	@Override
	public boolean deleteOneCurrentAccountById(int accountNumber) {
		// TODO Auto-generated method stub
		for (CurrentAccount currentAccount : currentAccountList) {
			if(currentAccount.getAccountNumber()==accountNumber);
			currentAccountList.remove(currentAccount);
			return true;
		}
		return false;
	}

}
