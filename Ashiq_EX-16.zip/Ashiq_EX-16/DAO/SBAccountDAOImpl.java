package com.ust.banking.DAO;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.ust.banking.Entity.SBAccount;

public class SBAccountDAOImpl implements SBAccountDAO{
	
	List<SBAccount> sbAccountList;
	
	 public SBAccountDAOImpl() {
		sbAccountList = new ArrayList<>();
		SBAccount sbAccount1= new SBAccount(11112, "SBAccountName1", 1000);
		SBAccount sbAccount2= new SBAccount(11113, "SBAccountName2", 1000);
		SBAccount sbAccount3= new SBAccount(11114, "SBAccountName3", 1000);
		SBAccount sbAccount4= new SBAccount(11115, "SBAccountName4", 1000);
		sbAccountList.add(sbAccount1);
		sbAccountList.add(sbAccount2);
		sbAccountList.add(sbAccount3);
		sbAccountList.add(sbAccount4);
	}
	 /*Method is for delete one SB account*/
	@Override
	public List<SBAccount> getAllSBAccount() {
		// TODO Auto-generated method stub
		return sbAccountList;
	}
	/*Method is for get one SB account by account number*/
	@Override
	public SBAccount getSBAAccountByNumber(int accountNumber) {
		// TODO Auto-generated method stub
		SBAccount sbAccount= null;
		Iterator<SBAccount> iterator= sbAccountList.iterator();
		while (iterator.hasNext()) {
			SBAccount sbAccount2 =iterator.next();
			if(sbAccount2.getAccountNumber()==accountNumber) {
				sbAccount=sbAccount2;
			}
			
		}
		return sbAccount;
	}
	/*Method is for delete one SB account*/
	@Override
	public boolean deleteOneSBAccountById(int accountNumber) {
		// TODO Auto-generated method stub
		for (SBAccount sbAccount : sbAccountList) {
			if (sbAccount.getAccountNumber()==accountNumber) {
				sbAccountList.remove(sbAccount);
				return true;
			}
		}
		return false;
	}

}
