package com.ust.banking.DAO;

import java.util.List;

import com.ust.banking.Entity.FDAccount;
/**
 * This is interface for Current Account.
 * Date: 06/10/2020
 */
public interface FDAccountDAO {
	/*Method is for get all FD accounts*/
	public List<FDAccount> getAllFdAccount();
	/*Method is for get one FD account by account number*/
	public FDAccount getFDAAccountByNumber(int accountNumber);
	/*Method is for delete one FD account*/
	public boolean deleteOneAccount(int accountNumber);
}
