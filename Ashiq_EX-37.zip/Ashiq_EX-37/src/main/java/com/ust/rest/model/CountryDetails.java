/**
 * Name: CountryDetails
 * Description: This is model class for country
 * Date: 10/22/2020
 * */

package com.ust.rest.model;

public class CountryDetails {

	private String code;
	private String description;
	
	/**
	 * accessor method for code
	 * */
	public String getCode() {
		return code;
	}
	/**
	 * Setter method for code
	 * */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * accessor method for description
	 * */
	public String getDescription() {
		return description;
	}
	/**
	 * Setter method for description
	 * */
	public void setDescription(String description) {
		this.description = description;
	}
	
}
