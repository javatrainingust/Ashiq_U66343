/**
 * Name: CountryController
 * Description: This is controller class for country
 * Date: 10/22/2020
 * */

package com.ust.rest.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ust.rest.model.CountryDetails;

/**
 * Controller class for country
 * */
@RestController
public class CountryController {

	Map<String, CountryDetails> countryDB = new HashMap<String, CountryDetails>();
	
	/**
	* getDummyCountry method to insert details of one country to the Map
	*/
	@RequestMapping(value= "/country/dummy", method= RequestMethod.GET)
	
	public CountryDetails getDummyCountry(){
		
	CountryDetails country= new CountryDetails();
	country.setCode("IN");
	country.setDescription("India");
	countryDB.put("IN", country);
	return country;

	 }
	
	/**
	* createCountry method to create country 
	*/
	@RequestMapping(value="/country",method=RequestMethod.POST) 
	public String createCountry(@RequestBody CountryDetails country) {

			
	if(countryDB.containsKey(country.getCode())) {
		return "Country already exist";
	}		
		else {
			countryDB.put(country.getCode(),country);
			return "Country added successfully";
		}	

		
	}
	/**
	* getAllCountryDetails method to get all country 
	*/
	@RequestMapping(value="/country",method=RequestMethod.GET)
	public List<CountryDetails> getAllCountryDetails(){
		
		List<CountryDetails> countryDetails= new ArrayList<CountryDetails>(countryDB.values());
		return countryDetails;
	}
	/**
	 * This method is to get one country by id
	 * */
	@RequestMapping(value="/country/{code}",method=RequestMethod.GET)
	public CountryDetails getOneCountry(@PathVariable String code) {
		
		return countryDB.get(code);
	}
	/**
	 * This method is to delete one country. 
	 * */
	@RequestMapping(value="/country/{code}",method=RequestMethod.DELETE)
	public String deleteCountry(@PathVariable String code) {
		
		if (countryDB.containsKey(code)) {
			countryDB.remove(code);
			return "Country deleted";
		} else {
			return "Country not exist";
		}
	}
	
}
