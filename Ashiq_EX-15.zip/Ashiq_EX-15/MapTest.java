package com.ust.collections.demo;

import java.util.HashMap;
import java.util.Map;

/**
 * The is test class for cat. 
 * Date: 05/10/2020
 */
public class MapTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map<String, String> movieActors= new HashMap<>();
		
		movieActors.put("Actor1", "Movie1");
		movieActors.put("Actor2", "Movie2");
		movieActors.put("Actor3", "Movie3");
		
		System.out.println("Movie of Actor1 is ::"+movieActors.get("Actor1"));
		
		Map<Cat, String> cats= new HashMap<>();
		Cat cat1= new Cat("rosy", 2);
		Cat cat2=new Cat("pinky", 3);
		Cat cat3=new Cat("rose", 4);
		
		cats.put(cat1, "Owner1");
		cats.put(cat2, "Owner2");
		cats.put(cat3, "Owner3");
		
		System.out.println("Owner of cat1 is ::"+cats.get(cat1));
	}

}
