package com.ust.collections.demo;

import java.util.HashSet;
import java.util.Set;
import java.util.Locale.Category;

/**
 * The is test class. 
 * Date: 05/10/2020
 */
public class SetTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1= "Test";
		String s2="Work";
		String s3="Test";
		
		Set<String> set=new HashSet<>();
		set.add(s1);
		set.add(s2);
		set.add(s3);
		
		for (String string : set) {
			System.out.println(string);
		}
		
		Set<Cat> cats=new HashSet<>();
		Cat cat1= new Cat("rosy", 2);
		Cat cat2=new Cat("pinky", 3);
		Cat cat3=new Cat("rosy", 2);
		
		cats.add(cat1);
		cats.add(cat2);
		cats.add(cat3);
		
		for (Cat cat : cats) {
			System.out.println(cat);
		}
	}

}
