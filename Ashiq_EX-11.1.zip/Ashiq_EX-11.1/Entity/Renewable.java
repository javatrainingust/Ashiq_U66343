package com.ust.banking.Entity;

/**interface for Renewable
 * Date: 30/09/2020
 */
public interface Renewable {
	/*Method for auto renewal*/
	public void autoRenewal(int tenure);
}
