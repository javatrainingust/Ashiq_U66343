package com.ust.banking.Entity;

/**CurrentAccount class is for customers having current account, and which inherits from Account
 *Date: 30/09/2020
 */
public class CurrentAccount extends Account{

	private float overDraftLimit=50000;
	/*No argument constructor for CurrentAccount class*/
	public CurrentAccount() {
		System.out.println("This is from CurrentAccount no arg construtor");
	}
	/*Accessor method for overDraftLimit*/
	public float getOverDraftLimit() {
		return overDraftLimit;
	}
	/*method for withdrawing money*/
	public float withdrawMoney(float amount) {
		
		 this.overDraftLimit=this.overDraftLimit-amount;
		 
		 return overDraftLimit;
	}
	/*method to find ammountCanWithdraw*/
	public float ammountCanWithdraw() {
		return overDraftLimit+getBalance();
	}
	}
