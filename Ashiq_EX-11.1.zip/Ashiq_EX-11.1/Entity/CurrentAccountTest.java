package com.ust.banking.Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;


/** This is test for CurrentAccount class
 * Date: 01/10/2020*/
class CurrentAccountTest {

	/*This method will test the withdrawMoney method*/
	@Test
	void testWithdrawMoney() {
		
		CurrentAccount currentAccount= new CurrentAccount();
		float actual= currentAccount.withdrawMoney(1000);
		float expected= 49000;
		assertEquals(expected, actual);
	}
	/*This method will test the AmmountCanWithdraw method*/
	@Test
	void testAmmountCanWithdraw() {
		CurrentAccount currentAccount= new CurrentAccount();
		float actual= currentAccount.getOverDraftLimit();
		float expected= 50000;
		assertEquals(expected, actual);
		
	}

}
