package com.ust.banking.Entity;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import com.ust.banking.util.ICalculator;
import com.ust.banking.util.InterestCalculator;

/**Class FDAccount for details of Fixed Deposit customers
 * Date: 30/09/2020
 */
public class FDAccount extends Account implements Renewable {

	private int tenure;
	private boolean autoRenewal=true;
	/*Default constructor for FDAccount*/
	public FDAccount() {
		System.out.println("This is from FDAccount no arg construtor");
	}
	/*Argument constructor for FDAccount*/
	public FDAccount(int tenure, boolean autoRenewal) {
		
		super();
		this.tenure = tenure;
		this.autoRenewal = autoRenewal;
		System.out.println("This is from FDAccount arg construtor");
	}
	
	private LocalDate maturityDate= LocalDate.of(2020, 2, 14);
	
	LocalDate currentDate = LocalDate.now();
	
	/*Accessor method for tenure*/
	public int getTenure() {
		return tenure;
	}
	/*Setter method for tenure*/
	public void setTenure(int tenure) {
		this.tenure = tenure;
	}
	/*Accessor method for isAutoRenewal*/
	public boolean isAutoRenewal() {
		return autoRenewal;
	}
	/*Setter method for isAutoRenewal*/
	public void setAutoRenewal(boolean autoRenewal) {
		this.autoRenewal = autoRenewal;
	}
	
	/*calculateInterest method is for interest calculation*/
	public float calculateInterest(int duration, ICalculator interestCalculator) {
		
	
	float total=	interestCalculator.intrestCalculator(duration, getBalance());
		
		System.out.println("Interest from Child FDAccount class :"+total);
		return total;
	}
	/*autoRenewal method is for renewing the FD*/
	@Override
	public void autoRenewal(int tenure) {
		
		if(autoRenewal==true && maturityDate.isBefore(currentDate)) {
			System.out.println("your FD renewed for "+tenure+ "years");
			this.maturityDate=currentDate.plusYears(tenure);
			System.out.println("New maturity date is "+ maturityDate);
		}
		
	}
}
