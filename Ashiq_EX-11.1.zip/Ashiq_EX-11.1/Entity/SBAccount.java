package com.ust.banking.Entity;

import com.ust.banking.util.InterestCalculator;
/**SBAccount class is for customers having SB account, and which inherits from Account
 *Date: 30/09/2020
 */
public class SBAccount extends Account {
	/*No argument constructor for account class*/
	public SBAccount() {
		System.out.println("This is from SBAccount no arg construtor");
	}
	
	InterestCalculator interestCalculator=new InterestCalculator();
	/*This method is for interest calculation*/
	public float calculateInterest(int duration) {
	float total=interestCalculator.intrestCalculator(getBalance(), duration);
		
		System.out.println("Interest from Chiled SBAccount :"+total);
		return total;
	}
}
