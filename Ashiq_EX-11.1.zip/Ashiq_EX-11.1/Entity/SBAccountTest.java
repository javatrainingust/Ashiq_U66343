package com.ust.banking.Entity;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ust.banking.util.InterestCalculator;

/** This is test for SBAccount class
 * Date: 01/10/2020*/
class SBAccountTest {
	
	/*This method will test the CalculateInterest method*/
	@Test
	void testCalculateInterest() {

		SBAccount sbAccount=new SBAccount();
		float expected=8.0f;
		float actual= sbAccount.calculateInterest(2);
		assertEquals(expected, actual);
	}

}
