package com.ust.banking.util;
/**interface for calculating interest
 * Date: 30/09/2020
 */
public interface ICalculator {
	/*Method for interest calculation*/
	public float intrestCalculator( int duration,float amount);
	
}
