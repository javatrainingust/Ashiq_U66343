package com.ust.banking.util;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
/** This is test for InterestCalculator class
 * Date: 01/10/2020*/
class InterestCalculatorTest {

	/*This method will test the IntrestCalculator method*/
	@Test
	void testIntrestCalculatorFloatInt() {
		
		InterestCalculator interestCalculator = new InterestCalculator();
		float expected=2.4f;
		float actual= interestCalculator.intrestCalculator(2000f, 3);
		assertEquals(expected, actual);
	}

	/*This method will test the IntrestCalculator method*/
	@Test
	void testIntrestCalculatorIntFloat() {
		
		InterestCalculator interestCalculator = new InterestCalculator();
		float expected=5.4f;
		float actual= interestCalculator.intrestCalculator(3, 2000f);
		assertEquals(expected, actual);
	}

}
