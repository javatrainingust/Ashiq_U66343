/**
 * Name:RestclientApplication
 * Description:RestclientApplication is the client application which consumes the sb account service
 * Date: 28/10/2020
 * */
package com.ust.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.ust.restclient.Entity.SBAccount;

/**
 * The client application which consumes the sb account service
 * */

@SpringBootApplication
public class RestclientApplication {

	/**
	 * Main method which will start execution. 
	 * */
	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
				
				//getResource();
		
				//postResource();
				
				//putResource();
				
				deleteResource();
				
				getAllResources();
				
				
			}
			
			/**
			 * This method will call the get one sb account url
			 * */
			public static void  getResource() {
				
				
				RestTemplate restTemplate = new RestTemplate();
				
				final String uri = "http://localhost:8000/banking/sbaccounts/{number}";
			    	     
			    Map<String, Integer> params = new HashMap<String, Integer>();
			    params.put("number", 111);
			     
			    SBAccount result = restTemplate.getForObject(uri, SBAccount.class, params);
			    
			    System.out.println("Account number: "+result.getAccountNumber());
			    System.out.println("Account holder name: "+result.getAccountHolderName());
			    	
			}
			
			/**
			 * This method will call the get all sb account url
			 * */
			public static void getAllResources() {
				
				System.out.println("Inside getAllResources() method");
			
				
				RestTemplate restTemplate = new RestTemplate();
				
				final String uri = "http://localhost:8000/banking/sbaccounts";
			    	     
			    	     
			    ResponseEntity<SBAccount[]> response  = restTemplate.getForEntity(uri, SBAccount[].class);
			    
			    SBAccount[] sbAccounts = response.getBody();

			    for (SBAccount sbAccount : sbAccounts) {
			    	
			    	System.out.println("Account number: "+sbAccount.getAccountNumber());
				    System.out.println("Account holder name: "+sbAccount.getAccountHolderName());
				}
				
				
			}
			/**
			 * This method will call the save one sb account url
			 * */
			public static void postResource() {
				
				
				RestTemplate restTemplate = new RestTemplate();
				
				final String uri = "http://localhost:8000/banking/sbaccounts";
			
				SBAccount sbAccount= new SBAccount(11112, "SBAccountNameD", 1000, 2000);
			
				SBAccount result = restTemplate.postForObject( uri, sbAccount, SBAccount.class);
				
			}
			
			/**
			 * This method will call the update one sb account url
			 * */
			public static void putResource() {
				
				RestTemplate restTemplate = new RestTemplate();
				
				final String uri = "http://localhost:8000/banking/sbaccounts/{number}";
			    	     
			    Map<String, Integer> params = new HashMap<String, Integer>();
			    params.put("number", 111);
			     
			    SBAccount sbAccountUpdated= new SBAccount(111, "SBAccountNameUpdated", 1000, 2000);
			    
			     restTemplate.put(uri, sbAccountUpdated, params);
					
			}
			/**
			 * This method will call the delete one sb account url
			 * */
			public static void deleteResource() {
				
				RestTemplate restTemplate = new RestTemplate();
				
				final String uri = "http://localhost:8000/banking/sbaccounts/{number}";
			    	     
			    Map<String, Integer> params = new HashMap<String, Integer>();
			    params.put("number", 111);
			     
			     restTemplate.delete(uri, params);
			}

		}

