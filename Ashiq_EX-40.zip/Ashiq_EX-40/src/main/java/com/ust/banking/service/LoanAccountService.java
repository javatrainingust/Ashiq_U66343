/**
 * Name: LoanAccountService
 * Descriptions: LoanAccountService contains business logics for loan account.   
 * Date: 06/10/2020
 */

package com.ust.banking.service;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.banking.DAO.LoanAccountDAO;
import com.ust.banking.DAO.LoanAccountDAOImpl;
import com.ust.banking.Entity.CurrentAccount;
import com.ust.banking.Entity.FDAccount;
import com.ust.banking.Entity.LoanAccount;
import com.ust.banking.Entity.SBAccount;
/**
 * This class contains methods get all loan account, get one loan account by account number loan outstanding,
 * delete one loan account, get all loan account sorted by name, get all loan account sorted by balance. 
 * 
 */
@Service
public class LoanAccountService {

@Autowired
LoanAccountDAO loanAccountDAO;
	/**Constructor for LoanAccountService*/

	public LoanAccountService() {
		
	}
	
	/**Method is for get all loan accounts*/
	public List<LoanAccount> getAllLoanAccount() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		
		return accounts;
	}
	
	/**Method is for get all loan accounts sorted by name*/
	public List<LoanAccount> getAllLoanAccountSortedByName() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		Collections.sort(accounts);
		return accounts;
	}
	
	/**Method is for get all loan accounts sorted by amount*/
	public List<LoanAccount> getAllLoanAccountSortedByAmount() {
		
		List<LoanAccount> accounts= loanAccountDAO.getAllLoanAccount();
		Collections.sort(accounts, new LoanAccountSortedAmount());
		return accounts;
	}
	
	/**Method is for get one loan account by account number*/
	public LoanAccount getLoanAccountByNumber(int accountNumber) {
		
		LoanAccount account= loanAccountDAO.getLoanAccountByNumber(accountNumber);
		
		return account;
	}
	
	/**Method is for delete one loan account*/
	public boolean deleteOneAccount(int accountNumber) {
		
		return loanAccountDAO.deleteOneLoanAccountById(accountNumber);
	}
	
	
	/**Method to add one Loan account*/
	public boolean addLoanAccount(LoanAccount loanAccount) {
		if (loanAccountDAO.addLoanAccount(loanAccount)) {
			System.out.println("Account added suceessfully- Account number : "+loanAccount.getAccountNumber());
			return true;
		} else {
			System.out.println("Duplicate account");
			return false;
		}
	}
	/**Method to update one Loan account*/
	public boolean updateAccount(LoanAccount loanAccount) {
		if (loanAccountDAO.updateLoanAccount(loanAccount)) {
			System.out.println("Account updated");
			return true;
		} else {
			System.out.println("Account not exist");
			return false;
		}
	}
	
}
