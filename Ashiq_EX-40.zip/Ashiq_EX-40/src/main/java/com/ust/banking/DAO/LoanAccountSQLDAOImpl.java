/**
 * Name: LoanAccountSQLDAOImpl
 * Description: This is implementation for SBAccountDAO interface.
 * Date: 23/10/2020
 */

package com.ust.banking.DAO;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.ust.banking.Entity.LoanAccount;

/**
 * This contains the methods which communicating with database. 
 * */
@Repository
public class LoanAccountSQLDAOImpl implements LoanAccountDAO {

	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplateObject;
		
		@Autowired
		public void setDataSource(DataSource dataSource) {
			this.dataSource = dataSource;
			jdbcTemplateObject = new JdbcTemplate(dataSource);
		}
	
		/**Method is for get all loan accounts*/
	@Override
	public List<LoanAccount> getAllLoanAccount() {
		
		String SQL = "select * from loanaccount";
	      List <LoanAccount> loanAccounts= jdbcTemplateObject.query(SQL, new LoanAccountMapper());
		return loanAccounts;
	}

	/**Method is for get one loan account by account number*/
	@Override
	public LoanAccount getLoanAccountByNumber(int accountNumber) {
		
		LoanAccount loanAccount;
		try {
			String sql = "SELECT * FROM loanaccount WHERE accountNumber = ?";
			 
			 loanAccount = (LoanAccount) jdbcTemplateObject.queryForObject(
	                sql, new Object[] { accountNumber }, new LoanAccountMapper());
		} catch (EmptyResultDataAccessException e) {
			loanAccount=null;
		}
		return loanAccount;
	}
	/**Method is for delete one loan account*/
	@Override
	public boolean deleteOneLoanAccountById(int accountNumber) {
		
		 String query="delete from loanaccount where accountNumber='"+accountNumber+"' ";  
		 jdbcTemplateObject.update(query);  
		
		return true;
	}
	/** Method is for add one loan account */
	@Override
	public boolean addLoanAccount(LoanAccount loanAccount) {
		
		String sql = "INSERT INTO loanaccount (accountNumber, accountHolderName, emi,loanOutStanding) VALUES (?, ?, ?,?)";
		  
		jdbcTemplateObject.update(sql, new Object[] {loanAccount.getAccountNumber(), loanAccount.getAccountHolderName(), loanAccount.getEmi(), loanAccount.getLoanOutStanding()});
		return true;
	}
	/** Method is for update one loan account */
	@Override
	public boolean updateLoanAccount(LoanAccount loanAccount) {
		
		String query="update sbaccount set  accountHolderName='"+loanAccount.getAccountHolderName()+"',"
				+ "emi='"+loanAccount.getEmi()+"' where accountNumber='"+loanAccount.getAccountNumber()+"' ";  
	    jdbcTemplateObject.update(query); 
		return true;
	}

}
