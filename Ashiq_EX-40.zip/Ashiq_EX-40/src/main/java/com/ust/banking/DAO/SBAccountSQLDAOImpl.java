/**
 * Name: SBAccountSQLDAOImpl
 * Description: This is implementation for SBAccountSQLDAO interface.
 * Date: 23/10/2020
 */

package com.ust.banking.DAO;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.ust.banking.Entity.SBAccount;

/**
 * SBAccountDAOImpl is the implementation class for SBAccountDAO
 */
@Repository
public class SBAccountSQLDAOImpl implements SBAccountDAO {

	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	/**
	 * Method is for get all SB account
	 */

	@Override
	public List<SBAccount> getAllSBAccount() {

		String SQL = "select * from sbaccount";
		List<SBAccount> sbAccounts = jdbcTemplateObject.query(SQL, new SBAccountMapper());
		return sbAccounts;
	}

	/** Method is for get one SB account by account number */
	@Override
	public SBAccount getSBAAccountByNumber(int accountNumber) {
		SBAccount sbAccount;

		try {
			String sql = "SELECT * FROM sbaccount WHERE accountNumber = ?";

			sbAccount = (SBAccount) jdbcTemplateObject.queryForObject(sql, new Object[] { accountNumber },
					new SBAccountMapper());
		} catch (EmptyResultDataAccessException e) {
			sbAccount = null;
		}

		return sbAccount;
	}

	/**
	 * Method is for delete one SB account
	 */
	@Override
	public boolean deleteOneSBAccountById(int accountNumber) {

		String query = "delete from sbaccount where accountNumber='" + accountNumber + "' ";
		jdbcTemplateObject.update(query);

		return true;
	}

	/** Method is for add one SB account */
	@Override
	public boolean addSBAccount(SBAccount sbAccount) {

		String sql = "INSERT INTO sbaccount (accountNumber, accountHolderName, minimumBalance,SBBalance) VALUES (?, ?, ?,?)";

		jdbcTemplateObject.update(sql, new Object[] { sbAccount.getAccountNumber(), sbAccount.getAccountHolderName(),
				sbAccount.getMinimumBalance(), sbAccount.getSBBalance() });
		return true;
	}

	/** Method is for update one SB account */
	@Override
	public boolean updateSBAccount(SBAccount sbAccount) {
		String query = "update sbaccount set  accountHolderName='" + sbAccount.getAccountHolderName() + "',"
				+ "minimumBalance='" + sbAccount.getMinimumBalance() + "' where accountNumber='"
				+ sbAccount.getAccountNumber() + "' ";
		jdbcTemplateObject.update(query);
		return true;
	}

}
