/**
 * Name:OneManBand
 * Description: OneManBand class is for demo.
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import java.util.List;

/**
 * This class contains property- List of instruments. 
 * */
public class OneManBand implements Performer{
	
	List<Instrument> instruments; 
	
	/**
	 * This method is for getting list of instruments. 
	 * */
	public List<Instrument> getInstruments() {
		return instruments;
	}
	/**
	 *  This method is for setting list of instruments. 
	 * */
	public void setInstruments(List<Instrument> instruments) {
		this.instruments = instruments;
	}
/**
 * this Perform method will iterates the list of instruments. 
 * */
	public void perform() {
		
		for (Instrument instrument : instruments) {
			
			instrument.play();
		}
		
	}

}
