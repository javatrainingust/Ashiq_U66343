package com.ust.competetion.bean;

public class Flute implements Instrument{

	public void play() {
		System.out.println("Play Flute");
		
	}

}
