package com.ust.competetion.bean;

public class Guitar implements Instrument{

	public void play() {
		System.out.println("Play Guitar");
		
	}

}
