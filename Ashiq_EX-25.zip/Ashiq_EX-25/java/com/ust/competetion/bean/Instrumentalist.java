/**
 * Name:Instrumentalist
 * Description: Instrumentalist contains a property of type Saxophone.
 * Date:12/10/2020
 * 
 * */

package com.ust.competetion.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * This class implements performer.
 */
@Component
public class Instrumentalist implements Performer {

	@Autowired
	Saxophone saxophone;

	public void perform() {
		// TODO Auto-generated method stub
		saxophone.play();
	}
	
	
	
	
	
	
	
	
	
	
	/**
	 * Get method for saxophone.
	 */
	/*
	 * public Saxophone getSaxophone() { return saxophone; }
	 * 
	 *//**
		 * Set method for saxophone
		 */

	/*
	 * public void setSaxophone(Saxophone saxophone) { this.saxophone = saxophone; }
	 *//**
		 * perform method will call play method of saxophone.
		 */
	

}
